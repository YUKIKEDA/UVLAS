#pragma once

#define UVLAS_GIT_COMMIT "dbe8a0381c974cb0b9e05c0b718b6f4541d357cd"
#define UVLAS_GIT_DIRTY 0
