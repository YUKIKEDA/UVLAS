"""Publish only redacted text evidence; retain private inputs and raw bytes."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

root = Path.cwd().resolve()
area = root / 'out/issue85-mutations'
snapshot = area / 'snapshot-139609c41df1-exact-bytes'
public = root / 'docs/verification/IM-06/im06-1'
public.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
report = json.loads((snapshot / 'report.json').read_text(encoding='utf-8'))
inputs = json.loads((snapshot / 'inputs/inputs.json').read_text(encoding='utf-8'))
assert len(report['results']) == 5
assert report['results'][0]['run_exit'] == 0
assert report['results'][0]['mutated_source_sha256'] == report['source_sha256']
assert all(x['compile_exit'] == x['link_exit'] == 0 for x in report['results'])
assert all(x['run_exit'] == 42 and x['killed'] for x in report['results'][1:])
for original, data in inputs.items():
    assert sha(Path(original).read_bytes()) == data['sha256']
    assert sha((snapshot / data['snapshot']).read_bytes()) == data['sha256']

policies = []
for prefix, replacement, label in [
    (str(root), '<workspace>', 'workspace-prefix'),
    ('<dependency-workspace>', '<dependency-workspace>', 'dependency-prefix'),
    ('<dependency-workspace>', '<dependency-workspace>', 'dependency-prefix'),
    ('<user-home>', '<user-home>', 'user-prefix')]:
    variants = {prefix, prefix.replace('\\', '/'), json.dumps(prefix)[1:-1],
                prefix.replace(':', '?3').replace('\\', '?2')}
    for value in sorted(variants, key=len, reverse=True):
        policies.append((re.compile(re.escape(value.encode()), re.I), replacement.encode(), label))
policies.append((re.compile(b'account', re.I), b'account', 'remaining-account-token'))

def redact(raw):
    derived = raw
    counts = {}
    for pattern, replacement, label in policies:
        derived, count = pattern.subn(lambda _: replacement, derived)
        if count:
            counts[label] = counts.get(label, 0) + count
    assert b'account' not in derived.lower()
    assert b'<dependency-workspace>' not in derived.lower()
    return derived, counts

def entry(source, name):
    raw = source.read_bytes()
    derived, counts = redact(raw)
    return derived, {'entry': name, 'raw_sha256': sha(raw), 'published_sha256': sha(derived),
                     'raw_bytes': len(raw), 'published_bytes': len(derived), 'replacements': counts}

selected = {snapshot / 'report.json', snapshot / 'inputs/inputs.json', Path(__file__).resolve()}
text_suffixes = {'.hpp', '.cpp', '.json', '.ninja', '.txt', '.py', '.md'}
selected.update(p for p in (snapshot / 'inputs').rglob('*') if p.is_file() and p.suffix in text_suffixes)
for result in report['results']:
    selected.update(snapshot / result['name'] / name for name in
                    ('input_scalar.cpp', 'compile-command.txt', 'compile.log',
                     'link-command.json', 'link.log', 'input_scalar.map', 'run.log'))
ledger = []
archive = public / 'mutations.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
    for path in sorted(selected):
        name = ('snapshot/' + path.relative_to(snapshot).as_posix() if path.is_relative_to(snapshot)
                else 'runner/' + path.name)
        derived, metadata = entry(path, name)
        bundle.writestr(name, derived)
        ledger.append(metadata)
    manifest = {'schema': 'uvlas.derived-evidence/1', 'source_commit': report['source_commit'],
                'source_sha256': report['source_sha256'], 'control_source_bytes_equal_product': True,
                'control': {'cases': 4, 'assertions': 1374, 'run_exit': 0},
                'mutants_killed': 4, 'all_compile_link_success': True,
                'frozen_inputs': len(inputs), 'input_mismatches': 0,
                'map_files': 5, 'original_archive_producer_matches': 0,
                'scope': 'Redacted text derivatives, not complete raw logs or a bundled binary toolchain. Private raw inputs, libraries, test objects and executables remain unchanged. Only filesystem/account spellings are substituted; product values and outcomes are preserved.',
                'excluded_binary_extensions': ['.obj', '.lib', '.exe', '.pdb'],
                'entries': ledger}
    serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    assert b'account' not in serialized.lower()
    bundle.writestr('redaction.json', serialized)
(public / 'mutation-redaction.json').write_bytes(serialized)

logs = root / 'out/issue85/logs'
log_names = ['configure.log', 'build-debug-final.log', 'build-release-final.log',
             'ctest-debug-final.log', 'ctest-release-final.log', 'format-check.log',
             'tidy-first.log', 'tidy-final-source.log', 'tidy-final-audit.log',
             'mutations-run.log', 'mutations-exact-bytes-run.log']
log_ledger = []
for name in log_names:
    published_name = 'safe-' + name
    derived, metadata = entry(logs / name, published_name)
    (public / published_name).write_bytes(derived)
    log_ledger.append(metadata)
derived, metadata = entry(logs / 'contract-japanese.json', 'safe-contract-japanese.log')
(public / 'safe-contract-japanese.log').write_bytes(derived)
log_ledger.append(metadata)
old = area / 'snapshot-139609c41df1'
bridge = {'first_control_source_sha256': sha((old / 'control/input_scalar.cpp').read_bytes()),
          'frozen_source_sha256': report['source_sha256'],
          'first_control_equals_after_newline_normalization':
              (old / 'control/input_scalar.cpp').read_bytes().replace(b'\r\n', b'\n') ==
              (snapshot / 'control/input_scalar.cpp').read_bytes(),
          'final_control_source_bytes_equal_product': True,
          'note': 'The preliminary runner wrote CRLF copies on Windows. Its outcomes are historical, not the final exact-byte control proof. A corrected write_bytes runner produced a distinct final snapshot and repeated control plus all four mutants; original preliminary bytes were retained.'}
assert bridge['first_control_equals_after_newline_normalization']
(public / 'mutation-control-bridge.json').write_bytes((json.dumps(bridge, indent=2) + '\n').encode())
(public / 'log-provenance.json').write_bytes((json.dumps({'schema': 'uvlas.redacted-text/1',
    'source_commit': report['source_commit'], 'note': 'Full text was redacted, not original raw bytes. Filesystem/account tokens only; raw private logs are retained.',
    'files': log_ledger}, ensure_ascii=False, indent=2) + '\n').encode())
summary = {'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
           'redaction_sha256': sha(serialized), 'archive_entries': len(ledger) + 1,
           'raw_report_sha256': sha((snapshot / 'report.json').read_bytes()),
           'raw_runner_sha256': sha((snapshot / 'inputs/run.py').read_bytes())}
(public / 'mutation-summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
