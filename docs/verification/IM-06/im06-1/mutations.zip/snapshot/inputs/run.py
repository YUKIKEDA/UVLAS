"""Frozen Release scalar mutations. Product inputs are never edited."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

root = Path.cwd().resolve()
build = root / 'out/issue85-build'
area = root / 'out/issue85-mutations'
expected = '139609c41df18fe7d758de1905e58534e08a325b2024684d42c69a96b4459fe1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
producer = root / 'src/io/input_scalar.cpp'
if sha(producer) != expected:
    raise RuntimeError('source is not the reviewed frozen version')
snapshot = area / ('snapshot-' + expected[:12] + '-exact-bytes')
snapshot.mkdir(exist_ok=False)
frozen = snapshot / 'inputs'
frozen.mkdir()
inputs = {}

def freeze(source, destination):
    before = sha(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    if sha(source) != before or sha(destination) != before:
        raise RuntimeError('input changed while freezing ' + str(source))
    inputs[str(source)] = {'sha256': before, 'snapshot': str(destination.relative_to(snapshot))}

freeze(Path(__file__).resolve(), frozen / 'run.py')
for header in sorted((root / 'include').rglob('*.hpp')):
    freeze(header, frozen / header.relative_to(root))
freeze(producer, frozen / 'src/io/input_scalar.cpp')
freeze(root / 'tests/io/input_scalar_test.cpp', frozen / 'tests/io/input_scalar_test.cpp')
freeze(build / 'compile_commands.json', frozen / 'compile_commands.json')
freeze(build / 'CMakeCache.txt', frozen / 'CMakeCache.txt')
for header in sorted((build / 'generated').rglob('*')):
    if header.is_file():
        freeze(header, frozen / 'generated' / header.relative_to(build / 'generated'))
commands = json.loads((frozen / 'compile_commands.json').read_text(encoding='utf-8-sig'))

def entry_for(suffix):
    entries = [x for x in commands if x['file'].replace('\\', '/').endswith('/' + suffix)
               and '/Release/' in x['output'].replace('\\', '/') and '_audit' not in x['output']]
    if len(entries) != 1:
        raise RuntimeError(('nonunique compile entry', suffix, len(entries)))
    return entries[0]

entry = entry_for('src/io/input_scalar.cpp')
test_entry = entry_for('tests/io/input_scalar_test.cpp')
freeze(build / test_entry['output'], frozen / 'input_scalar_test.obj')
freeze(build / 'CMakeFiles/impl-Release.ninja', frozen / 'link-input.ninja')
link_text = (frozen / 'link-input.ninja').read_text(encoding='utf-8')
block = re.search(r'build tests[\\/]Release[\\/]uvlas_test_io_input_scalar\.exe:.*?\n(?=build |\n\n)', link_text, re.S)
if block is None:
    raise RuntimeError('missing target link block')
library_line = re.search(r'  LINK_LIBRARIES = ([^\n]+)', block[0])
if library_line is None:
    raise RuntimeError('missing original link libraries')
libraries = []
for token in library_line[1].split():
    path = Path(token)
    if not path.is_absolute():
        path = build / path
    if path.is_file():
        destination = frozen / 'libraries' / path.name
        if destination.exists() and sha(destination) != sha(path):
            raise RuntimeError('library filename collision')
        freeze(path, destination)
        libraries.append(str(destination))
    else:
        libraries.append(token)
(frozen / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8')
source = (frozen / 'src/io/input_scalar.cpp').read_text(encoding='utf-8')
mutations = [
    ('double_roundtrip', '    return value;\n}\n\ncore::Result<core::Index>',
     '    if (value <= 9223372036854775807ULL)\n        value = static_cast<std::uint64_t>(static_cast<double>(value));\n    return value;\n}\n\ncore::Result<core::Index>'),
    ('allow_plus', '        const auto character = text[i];',
     "        const auto character = text[i];\n        if (i == 0 && character == '+') continue;"),
    ('omit_id_overflow', 'return reject(ScalarConversionReason::IdOverflow, i, diagnostic, details);',
     'static_cast<void>(diagnostic);'),
    ('omit_index_overflow',
     'return reject(ScalarConversionReason::IndexOverflow,\n                                                            std::nullopt, diagnostic, details);',
     'static_cast<void>(details);')]
(frozen / 'mutations.json').write_text(json.dumps(mutations, indent=2) + '\n', encoding='utf-8')
report = {'source_commit': '20e2cc0b1c82588dc1fb0fa4f30ed476996ac218',
          'source_sha256': expected, 'source_tree_modified': False, 'results': []}
cache = (frozen / 'CMakeCache.txt').read_text(encoding='utf-8')
installed = re.search(r'^VCPKG_INSTALLED_DIR:[^=]+=(.+)$', cache, re.M)
if installed is None:
    raise RuntimeError('missing dependency prefix')
env = dict(os.environ)
env['PATH'] = str(Path(installed[1].strip()) / 'x64-windows/bin') + os.pathsep + env['PATH']

def unchanged():
    for original, data in inputs.items():
        if sha(Path(original)) != data['sha256']:
            raise RuntimeError('live input changed: ' + original)

def execute(command, cwd, log, timeout=180):
    started = time.monotonic()
    completed = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True,
                               encoding='utf-8', errors='replace', timeout=timeout)
    output = completed.stdout + completed.stderr
    log.write_text(output, encoding='utf-8')
    return completed.returncode, time.monotonic() - started, output

for name, before, after in [('control', '', ''), *mutations]:
    unchanged()
    case = snapshot / name
    case.mkdir()
    text = source
    if before:
        if text.count(before) != 1:
            raise RuntimeError((name, 'mutation anchor count', text.count(before)))
        text = text.replace(before, after)
    copied = case / 'input_scalar.cpp'
    copied.write_bytes(text.encode('utf-8'))
    command = entry['command'].replace(entry['file'], str(copied))
    for original, destination in [(root / 'include', frozen / 'include'),
                                  (build / 'generated', frozen / 'generated')]:
        for spelling in (str(original), str(original).replace('\\', '/')):
            command = command.replace(spelling, str(destination))
    command = re.sub(r'/Fo\S+', lambda _: '/Fo' + str(case / 'producer.obj'), command, count=1)
    command = re.sub(r'/Fd\S+', lambda _: '/Fd' + str(case / 'producer.pdb'), command, count=1)
    (case / 'compile-command.txt').write_text(command, encoding='utf-8')
    compile_exit, compile_seconds, _ = execute(command, build, case / 'compile.log')
    if compile_exit:
        raise RuntimeError((name, 'compile failure does not kill', compile_exit))
    executable = case / 'input_scalar.exe'
    map_path = case / 'input_scalar.map'
    link = ['link.exe', '/nologo', str(frozen / 'input_scalar_test.obj'), str(case / 'producer.obj'),
            '/OUT:' + str(executable), '/MAP:' + str(map_path), '/PDB:' + str(case / 'linked.pdb'),
            '/INCREMENTAL:NO', '/SUBSYSTEM:CONSOLE', *libraries]
    (case / 'link-command.json').write_text(json.dumps(link, indent=2) + '\n', encoding='utf-8')
    link_exit, link_seconds, _ = execute(link, build, case / 'link.log')
    if link_exit:
        raise RuntimeError((name, 'link failure does not kill', link_exit))
    mapping = map_path.read_text(encoding='utf-8')
    archive = re.findall(r'uvlas_io[^\r\n]*[:(]input_scalar\.cpp\.obj', mapping, re.I)
    own = {key: sum(key in line and 'producer.obj' in line for line in mapping.splitlines())
           for key in ('read_id_digits', 'read_index')}
    if archive or not all(own.values()):
        raise RuntimeError((name, 'original archive bypass', len(archive), own))
    runtime, seconds, output = execute([str(executable), '--reporter', 'compact'], root,
                                       case / 'run.log', 60)
    killed = runtime != 0 and 'failed' in output.lower()
    if name == 'control' and runtime:
        raise RuntimeError(('control runtime failed', runtime))
    if name != 'control' and not killed:
        raise RuntimeError((name, 'survived or not an assertion', runtime))
    unchanged()
    report['results'].append({'name': name, 'compile_exit': compile_exit, 'link_exit': link_exit,
                             'run_exit': runtime, 'killed': killed, 'compile_seconds': compile_seconds,
                             'link_seconds': link_seconds, 'run_seconds': seconds,
                             'archive_producer_matches': len(archive), 'own_symbols': own,
                             'mutated_source_sha256': sha(copied), 'input_count': len(inputs),
                             'input_mismatches': 0})
    (snapshot / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report['results'][-1]), flush=True)
print(json.dumps({'snapshot': str(snapshot), 'control_passed': True, 'mutants_killed': 4}), flush=True)
