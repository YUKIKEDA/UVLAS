#pragma once

#define UVLAS_GIT_COMMIT "20e2cc0b1c82588dc1fb0fa4f30ed476996ac218"
#define UVLAS_GIT_DIRTY 0
