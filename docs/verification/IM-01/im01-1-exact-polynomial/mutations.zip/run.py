from pathlib import Path
import json,subprocess,hashlib,re,shutil
root=Path.cwd();out=root/'out/issue87-mutations';build=root/'out/issue87-build';snap=out/'snapshot';snap.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={}
for rel in ['src/structure/exact_polynomial.cpp','src/structure/exact_polynomial_detail.hpp','tests/structure/exact_polynomial_test.cpp','tests/structure/fixtures/exact-polynomial-v1.json']:
 src=root/rel;dst=snap/rel;dst.parent.mkdir(parents=True,exist_ok=True);data=src.read_bytes();dst.write_bytes(data);assert dst.read_bytes()==data;inputs[rel]=sha(data)
shutil.copytree(root/'include',snap/'include',dirs_exist_ok=True)
source=(snap/'src/structure/exact_polynomial.cpp').read_bytes()
db=json.loads((build/'compile_commands.json').read_text());entry=next(x for x in db if x['file'].endswith('exact_polynomial.cpp') and 'Release' in x['command'] and 'uvlas_structure.dir' in x['command'])
cmd=entry['command'];cmd=cmd.replace(str(root/'include').replace('\\','/'),str(snap/'include').replace('\\','/')).replace(str(root/'include'),str(snap/'include'))
ninja=(build/'CMakeFiles/impl-Release.ninja').read_text();part=ninja[ninja.index('build tests\\Release\\uvlas_test_structure_exact_polynomial.exe:'):];part=part[:part.index('\n\n')];libs=re.search(r'  LINK_LIBRARIES = (.*)',part)[1].split()
libs=[str(build/x) if x.startswith('Release\\') else x for x in libs]
testobj=build/'tests/CMakeFiles/uvlas_test_structure_exact_polynomial.dir/Release/structure/exact_polynomial_test.cpp.obj'
cases=[('control',None,None),('normalization',b'    result.backend().normalize();',b'    // mutant: omitted normalize'),('binary64_subnormal',b'exponent == 0 ? -1074 :',b'exponent == 0 ? -1073 :'),('derivative_factor',b'Rational{d - k}, Arithmetic::Multiply',b'Rational{1}, Arithmetic::Multiply'),('integral_lower_sign',b'            constant_value.backend().negate();',b'            // mutant: omitted lower sign')]
results=[]
for name,old,new in cases:
 case=out/name;case.mkdir(exist_ok=True);src=case/'exact_polynomial.cpp';data=source
 if old is not None:assert data.count(old)==1,(name,data.count(old));data=data.replace(old,new)
 src.write_bytes(data);obj=case/'producer.obj';exe=case/'test.exe';mapping=case/'link.map'
 command=cmd.replace(entry['file'],str(src)).replace(entry['file'].replace('\\','/'),str(src))
 command=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),command)
 command += ' /I'+str(snap/'src/structure')
 (case/'compile-command.txt').write_text(command)
 with (case/'compile.log').open('wb') as f:r=subprocess.run(command,cwd=entry['directory'],stdout=f,stderr=subprocess.STDOUT,timeout=120)
 assert r.returncode==0,(name,'compile',r.returncode)
 link=['link.exe','/NOLOGO','/INCREMENTAL:NO','/SUBSYSTEM:CONSOLE','/OUT:'+str(exe),'/MAP:'+str(mapping),str(obj),str(testobj),*libs]
 (case/'link-command.json').write_text(json.dumps(link))
 with (case/'link.log').open('wb') as f:r=subprocess.run(link,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 assert r.returncode==0,(name,'link',r.returncode)
 with (case/'run.log').open('wb') as f:r=subprocess.run([str(exe)],cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 maptext=mapping.read_text();assert 'uvlas_structure:exact_polynomial.cpp.obj' not in maptext
 assert r.returncode==(0 if name=='control' else 42),(name,r.returncode)
 results.append({'case':name,'compile_exit':0,'link_exit':0,'run_exit':r.returncode,'source_sha256':sha(data),'original_archive_member_extracted':False});print(name,r.returncode,flush=True)
for rel,digest in inputs.items():assert sha((root/rel).read_bytes())==digest
(out/'results.json').write_text(json.dumps({'inputs':inputs,'results':results},indent=2))
