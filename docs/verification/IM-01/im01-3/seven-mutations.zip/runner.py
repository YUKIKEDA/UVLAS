from __future__ import annotations
import ctypes, hashlib, json, os, re, shutil, subprocess, sys, time, traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
BUILD=ROOT/'out/issue94-build'
COMMIT='de292e7e8afc1206c5a0cd6f22cfc34c66d6dfd6'
PREFIX=ROOT.parent.parent/'uvlas-im00-9/UVLAS/out/issue99-vcpkg-installed/x64-windows'
# ROOT is .../worktrees/uvlas-im01-contract/UVLAS.
PREFIX=ROOT.parents[1]/'uvlas-im00-9/UVLAS/out/issue99-vcpkg-installed/x64-windows'
OLD_PREFIX=Path('<repo>/out/vcpkg_installed/x64-windows')
PRIVATE='PG flat lifted fields retain full moment carry and physical-plane signs'
FACTORY='PG full preparation admits before allocating and owns its graph and exact values'
REFERENCE='PG complete dictionaries match the independent canonical coefficient fixture'
MUTATIONS=[
 ('omit-t-family','src/structure/pg_coefficients_generate.hpp','for (const auto paired_axis : {PgPairedAxis::S, PgPairedAxis::T}) {','for (const auto paired_axis : {PgPairedAxis::S}) {',FACTORY),
 ('reset-moment-carry','src/structure/pg_coefficients_algebra.hpp','result.completed[j] = op.constant(endpoint);','result.completed[j] = op.constant(endpoint.sign() == 0 ? endpoint : op.zero);',PRIVATE),
 ('reverse-director-x-sign','src/structure/pg_coefficients_algebra.hpp','auto px = op.sub(op.m(xy, ty), op.m(V, tx));','auto px = op.sub(op.m(V, tx), op.m(xy, ty));',PRIVATE),
 ('replace-4n-by-3n','src/structure/pg_coefficients.cpp','const auto scale = op.number(4 * view.n);','const auto scale = op.number(3 * view.n);',REFERENCE),
 ('anchor-at-each-cell-left','src/structure/pg_coefficients_anchor.hpp','traces[static_cast<std::size_t>(ct)]));','pg_anchor(op, g.get(column, {cs, ct}, field))));',FACTORY),
 ('omit-p-anchor-family','src/structure/pg_coefficients_anchor.hpp','for (const auto field : {PgCoefficientField::R, PgCoefficientField::P})','for (const auto field : {PgCoefficientField::R})',FACTORY),
 ('omit-required-map','src/structure/pg_coefficients.cpp','maps.required(view);','/* mutation: required map omitted */',FACTORY),
]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def command_argv(s):
 argc=ctypes.c_int()
 f=ctypes.windll.shell32.CommandLineToArgvW
 f.restype=ctypes.POINTER(ctypes.c_wchar_p)
 f.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
 ptr=f(s,ctypes.byref(argc))
 if not ptr:raise OSError('CommandLineToArgvW failed')
 try:return [ptr[i] for i in range(argc.value)]
 finally:ctypes.windll.kernel32.LocalFree(ptr)
def execute(argv,cwd,log,timeout):
 started=time.time()
 try:
  p=subprocess.run(argv,cwd=cwd,env=ENV,capture_output=True,timeout=timeout,check=False)
  log.write_bytes(p.stdout+b'\nSTDERR\n'+p.stderr)
  return {'exit':p.returncode,'seconds':time.time()-started,'timed_out':False,'argv':argv,'log':str(log)}
 except subprocess.TimeoutExpired as e:
  log.write_bytes((e.stdout or b'')+b'\nTIMEOUT\n'+(e.stderr or b''))
  return {'exit':None,'seconds':time.time()-started,'timed_out':True,'argv':argv,'log':str(log)}
def snapshot():
 actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 if actual!=COMMIT:raise RuntimeError(f'unexpected source revision {actual}')
 files=subprocess.check_output(['git','ls-tree','-r','--name-only',COMMIT,'--','include','src/structure','tests/structure'],cwd=ROOT,text=True).splitlines()
 files=[f for f in files if f.startswith('include/') or f.startswith('src/structure/') or f in ['tests/structure/pg_coefficients_test.cpp','tests/structure/pg_coefficients_reference_test.cpp','tests/structure/pg_coefficients_resource_test.cpp','tests/structure/fixtures/pg-coefficients-v1.json']]
 dst=WORK/'control/source';dst.mkdir(parents=True)
 original={};blobs={}
 for name in files:
  src=ROOT/name;target=dst/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
  original[name]=digest(src)
  if digest(target)!=original[name]:raise RuntimeError('copy changed '+name)
  blobs[name]=hashlib.sha256(subprocess.check_output(['git','show',COMMIT+':'+name],cwd=ROOT)).hexdigest()
 write_json(WORK/'source-set.json',{'commit':COMMIT,'working_snapshot':original,'git_blob_contents':blobs,'control_copy_byte_identical':True})
 return dst,original
def copy_inputs():
 inputs=WORK/'inputs';inputs.mkdir()
 paths=[BUILD/'Release/uvlas_structure.lib',BUILD/'Release/uvlas_core.lib',PREFIX/'lib/manual-link/Catch2Main.lib',PREFIX/'lib/Catch2.lib',PREFIX/'lib/boost_container-vc145-mt-x64-1_92.lib',PREFIX/'lib/boost_random-vc145-mt-x64-1_92.lib']
 inputs_manifest=[]
 for p in paths:
  if not p.is_file():raise RuntimeError('missing frozen input '+str(p))
  dst=inputs/p.name;shutil.copyfile(p,dst)
  if digest(p)!=digest(dst):raise RuntimeError('library copy mismatch')
  inputs_manifest.append({'original':str(p),'copy':str(dst),'sha256':digest(dst)})
 write_json(WORK/'input-libraries.json',inputs_manifest)
 return inputs_manifest
def compile_one(variant,source_root,role):
 names={'producer':'src/structure/pg_coefficients.cpp','normal':'tests/structure/pg_coefficients_test.cpp','reference':'tests/structure/pg_coefficients_reference_test.cpp'}
 rel=names[role]
 candidates=[e for e in DB if Path(e['file']).name==Path(rel).name and 'Release' in e['command']]
 if role=='producer':candidates=[e for e in candidates if 'uvlas_structure.dir' in e['command']]
 if len(candidates)!=1:raise RuntimeError('compile DB selection '+role+':'+str(len(candidates)))
 args=command_argv(candidates[0]['command']);out=variant/(role+'.obj');dep=variant/(role+'-dependencies.json')
 result=[]
 for a in args:
  if a.startswith('/Fo'):a='/Fo'+str(out)
  elif a.startswith('/Fd'):a='/Fd'+str(variant/(role+'.pdb'))
  else:
   a=a.replace(str(ROOT),str(source_root)).replace(ROOT.as_posix(),source_root.as_posix())
   a=a.replace(str(OLD_PREFIX),str(PREFIX)).replace(OLD_PREFIX.as_posix(),PREFIX.as_posix())
  result.append(a)
 result.extend(['/sourceDependencies',str(dep)])
 record=execute(result,source_root,variant/(role+'-compile.log'),180)
 if record['exit']!=0:raise RuntimeError('compile failed '+str(variant)+'/'+role)
 record['object_sha256']=digest(out)
 return record,out
def link_variant(folder,objects):
 linker=Path(command_argv(next(e['command'] for e in DB if e['file'].endswith('pg_coefficients.cpp') and 'Release' in e['command']))[0]).with_name('link.exe')
 exe=folder/'runner.exe';mapfile=folder/'runner.map';inputs=WORK/'inputs'
 argv=[str(linker),'/nologo',*[str(p) for p in objects],'/out:'+str(exe),'/implib:'+str(folder/'runner.lib'),'/pdb:'+str(folder/'runner.pdb'),'/map:'+str(mapfile),'/machine:x64','/INCREMENTAL:NO','/subsystem:console',str(inputs/'Catch2Main.lib'),str(inputs/'uvlas_structure.lib'),str(inputs/'Catch2.lib'),str(inputs/'uvlas_core.lib'),'psapi.lib',str(inputs/'boost_container-vc145-mt-x64-1_92.lib'),str(inputs/'boost_random-vc145-mt-x64-1_92.lib'),'kernel32.lib','user32.lib','gdi32.lib','winspool.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','advapi32.lib']
 r=execute(argv,folder,folder/'link.log',90)
 if r['exit']!=0:raise RuntimeError('link failed '+folder.name)
 text=mapfile.read_text(encoding='utf-8',errors='replace')
 old_matches=[line for line in text.splitlines() if 'pg_coefficients.cpp.obj' in line.lower()]
 if old_matches:raise RuntimeError('archive producer extracted '+folder.name)
 r.update(executable_sha256=digest(exe),map_sha256=digest(mapfile),archive_producer_matches=len(old_matches))
 return r,exe
ENV=dict(os.environ)
ENV['PATH']=str(PREFIX/'bin')+os.pathsep+ENV.get('PATH','')
DB=json.loads((BUILD/'compile_commands.json').read_bytes())
RESULT={'source_commit':COMMIT,'kind':'isolated-compiled-mutations','scientific_acceptance':'not_evaluated','variants':[]}
def save():write_json(WORK/'result.json',RESULT)
def main():
 control,original=snapshot();RESULT['source_set_sha256']=digest(WORK/'source-set.json');RESULT['libraries']=copy_inputs()
 base=control.parent
 comp=[];objs={}
 for role in ['producer','normal','reference']:
  r,obj=compile_one(base,control,role);comp.append(r);objs[role]=obj
 deps=json.loads((base/'reference-dependencies.json').read_bytes())
 includes=deps['Data']['Includes']
 private=[p for p in includes if Path(p).name.startswith('pg_coefficients_') and Path(p).suffix=='.hpp']
 if private:raise RuntimeError('reference TU unexpectedly consumes producer inline')
 lr,exe=link_variant(base,[objs['producer'],objs['normal'],objs['reference']])
 filt=','.join([PRIVATE,FACTORY,REFERENCE])
 rr=execute([str(exe),filt,'--abort','--colour-mode','none'],base,base/'run.log',300)
 entry={'name':'control','compile':comp,'link':lr,'run':rr,'reference_private_producer_dependencies':private,'success':rr['exit']==0}
 RESULT['variants'].append(entry);save()
 print('CONTROL',rr['exit'],round(rr['seconds'],3),flush=True)
 if rr['exit']!=0:raise RuntimeError('unchanged control failed')
 for name,file,old,new,filt in MUTATIONS:
  variant=WORK/name;src=variant/'source';shutil.copytree(control,src)
  target=src/file;before=target.read_bytes();needle=old.encode();replacement=new.encode()
  if before.count(needle)!=1:raise RuntimeError('mutation anchor count '+name+':'+str(before.count(needle)))
  target.write_bytes(before.replace(needle,replacement))
  write_json(variant/'mutation.json',{'file':file,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest(target),'replacements':1,'before':old,'after':new})
  comp=[];objects={}
  roles=['producer','normal'] if file.endswith('.hpp') else ['producer']
  for role in roles:r,obj=compile_one(variant,src,role);comp.append(r);objects[role]=obj
  for role in ['producer','normal','reference']:objects.setdefault(role,objs[role])
  lr,exe=link_variant(variant,[objects['producer'],objects['normal'],objects['reference']])
  rr=execute([str(exe),filt,'--abort','--colour-mode','none'],variant,variant/'run.log',120)
  text=(variant/'run.log').read_text(encoding='utf-8',errors='replace')
  caught=rr['exit']==42 and ('FAILED:' in text or 'failed:' in text)
  RESULT['variants'].append({'name':name,'mutation':file,'compile':comp,'link':lr,'run':rr,'killed':caught,'normal_recompiled':file.endswith('.hpp'),'reference_object_reused_from_control':True})
  save();print('MUTANT',name,rr['exit'],'KILLED',caught,flush=True)
  if not caught:raise RuntimeError('mutation not killed '+name)
 for path,h in original.items():
  if digest(ROOT/path)!=h:raise RuntimeError('original changed '+path)
 for item in RESULT['libraries']:
  if digest(item['original'])!=item['sha256'] or digest(item['copy'])!=item['sha256']:raise RuntimeError('input library changed')
 RESULT.update(original_sources_unchanged=True,input_libraries_unchanged=True,control_source_copy_unchanged=all(digest(control/p)==h for p,h in original.items()),completed=True)
 save();print('COMPLETE',len(MUTATIONS),'mutations',flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  RESULT['error']=traceback.format_exc();save();print(RESULT['error'],flush=True);sys.exit(1)
