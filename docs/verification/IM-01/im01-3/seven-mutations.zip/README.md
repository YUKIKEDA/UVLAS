# PG coefficient isolated mutations

Fixed producer revision: de292e7e8afc1206c5a0cd6f22cfc34c66d6dfd6.

`control/source` contains 42 byte-identical source/input files. Each mutant source directory contains only the changed file; start with the control tree and replace that file. `mutation.json` records the exact one-site replacement. The normal TU and producer object were rebuilt together for header mutations. Public-only reference test object reuse is justified by the saved compiler dependency output.

`result-final.json` records executed commands, binary/object/map hashes and outcomes. `result.json` preserves the initial attempt, including the surviving anchor property run. `mutation-summary.json` states the final scope. Logs and link maps were anonymized with a before/after hash ledger; original raw files remain outside this archive in the local execution directory. No source was changed in the original checkout.

This archive is evidence, not an independently packaged toolchain. Reproduction requires the same compiler/SDK and dependency versions, a readonly dependency prefix, and restored local path aliases. Runtime source fixtures were read from the frozen control snapshot. No binaries or dependency libraries are distributed in this source archive.
