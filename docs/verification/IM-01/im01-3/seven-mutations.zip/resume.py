from pathlib import Path
import importlib.util,json,traceback,sys
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pg_mutation_runner',BASE/'runner.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
initial=json.loads((BASE/'result.json').read_bytes())
FINAL=json.loads(json.dumps(initial));FINAL['initial_attempt_manifest_sha256']=r.digest(BASE/'result.json');FINAL['initial_attempt_error']=FINAL.pop('error',None)
def save():r.write_json(BASE/'result-final.json',FINAL)
try:
 anchor=FINAL['variants'][-1]
 assert anchor['name']=='anchor-at-each-cell-left' and anchor['run']['exit']==0
 folder=BASE/anchor['name'];exe=folder/'runner.exe'
 old_run=anchor['run']
 run=r.execute([str(exe),r.REFERENCE,'--abort','--colour-mode','none'],folder,folder/'run-reference.log',120)
 text=(folder/'run-reference.log').read_text(encoding='utf-8',errors='replace')
 killed=run['exit']==42 and ('FAILED:' in text or 'failed:' in text)
 anchor.update(run=run,killed=killed,first_filter_survived=True,runs=[old_run,run],filter_change_reason='Factory property filter observes the original anchor only; the existing fixture observes completed columns on other cells. The same control already passed the fixture filter.')
 save();print('ANCHOR FIXTURE',run['exit'],'KILLED',killed,flush=True)
 if not killed:raise RuntimeError('anchor fixture did not kill')
 objects={role:BASE/'control'/(role+'.obj') for role in ['producer','normal','reference']}
 control=BASE/'control/source'
 for name,file,old,new,filt in r.MUTATIONS[5:]:
  variant=BASE/name;src=variant/'source';r.shutil.copytree(control,src)
  target=src/file;before=target.read_bytes();needle=old.encode();replacement=new.encode()
  assert before.count(needle)==1
  target.write_bytes(before.replace(needle,replacement))
  r.write_json(variant/'mutation.json',{'file':file,'before_sha256':r.hashlib.sha256(before).hexdigest(),'after_sha256':r.digest(target),'replacements':1,'before':old,'after':new})
  comp=[];objs={}
  roles=['producer','normal'] if file.endswith('.hpp') else ['producer']
  for role in roles:
   c,obj=r.compile_one(variant,src,role);comp.append(c);objs[role]=obj
  for role in objects:objs.setdefault(role,objects[role])
  link,exe=r.link_variant(variant,[objs['producer'],objs['normal'],objs['reference']])
  run=r.execute([str(exe),filt,'--abort','--colour-mode','none'],variant,variant/'run.log',120)
  text=(variant/'run.log').read_text(encoding='utf-8',errors='replace')
  killed=run['exit']==42 and ('FAILED:' in text or 'failed:' in text)
  FINAL['variants'].append({'name':name,'mutation':file,'compile':comp,'link':link,'run':run,'killed':killed,'normal_recompiled':file.endswith('.hpp'),'reference_object_reused_from_control':True})
  save();print('MUTANT',name,run['exit'],'KILLED',killed,flush=True)
  if not killed:raise RuntimeError('not killed '+name)
 original=json.loads((BASE/'source-set.json').read_bytes())['working_snapshot']
 assert all(r.digest(r.ROOT/p)==h and r.digest(control/p)==h for p,h in original.items())
 assert all(r.digest(v['original'])==v['sha256'] and r.digest(v['copy'])==v['sha256'] for v in FINAL['libraries'])
 FINAL.update(original_sources_unchanged=True,control_source_copy_unchanged=True,input_libraries_unchanged=True,completed=True)
 save();print('COMPLETE 7 mutations',flush=True)
except Exception:
 FINAL['resume_error']=traceback.format_exc();save();print(FINAL['resume_error'],flush=True);sys.exit(1)
