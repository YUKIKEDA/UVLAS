import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
HERE = pathlib.Path(__file__).resolve().parent
BUILD = ROOT / 'out/issue95-build'
PREFIX = pathlib.Path('<dependency-worktree>/out/vcpkg_python_installed/x64-windows')
SOURCE = ROOT / 'src/aero/geometry_snapshot.cpp'
HEADER = ROOT / 'src/aero/geometry_snapshot.hpp'
TEST = ROOT / 'tests/aero/geometry_snapshot_test.cpp'
DB = BUILD / 'compile_commands.json'
TESTOBJ = BUILD / 'tests/CMakeFiles/uvlas_test_aero_geometry_snapshot.dir/Release/aero/geometry_snapshot_test.cpp.obj'
LIB = BUILD / 'Release/uvlas_aero.lib'
CORE = BUILD / 'Release/uvlas_core.lib'
CASES = [
 ('control',None,None),
 ('alias_inequality_ignored','if (arithmetic.coordinate != arithmetic.sum)','if (false && arithmetic.coordinate != arithmetic.sum)'),
 ('drop_low_word','output += temporary;','output += 0;'),
 ('substitute_snapshot','data.identity != query.geometry_->identity || !same_context(context, query.context_)','!same_context(context, query.context_)'),
 ('wrong_quad_scatter','QuadLRScatter{{1, 0, 0, 1, 0, 1}}','QuadLRScatter{{1, 0, 0, 1, 1, 0}}'),
 ('wrong_incidence','row.incidence[i] = -1;','row.incidence[i] = 1;'),
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def call(command, directory, path):
    started = time.monotonic()
    with path.open('wb') as stream:
        result = subprocess.run(command, cwd=directory, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    return {'exit': result.returncode, 'seconds': time.monotonic() - started}

def main():
    paths = [SOURCE, HEADER, TEST, DB, TESTOBJ, LIB, CORE]
    paths += sorted((ROOT/'src/aero').glob('*.hpp'))
    paths.append(ROOT/'tests/aero/geometry_snapshot_fixture.hpp')
    before = {str(path): sha(path) for path in paths}
    snapshot = HERE / 'snapshot-byte-exact'
    snapshot.mkdir(exist_ok=False)
    for index, path in enumerate(paths):
        shutil.copyfile(path, snapshot / f'{index}-{path.name}')
    entries = json.loads(DB.read_text())
    entry = [e for e in entries if pathlib.Path(e['file']) == SOURCE and 'uvlas_aero.dir' in e['output'] and 'Release' in e['output']]
    if len(entry) != 1:
        raise RuntimeError('Ambiguous source compile command')
    results = []
    for name, old, new in CASES:
        case = snapshot / name
        case.mkdir()
        text = SOURCE.read_bytes().decode('utf-8')
        if old is not None:
            if text.count(old) != 1:
                raise RuntimeError(f'{name}: anchor count {text.count(old)}')
            text = text.replace(old, new)
        source = case / SOURCE.name
        source.write_bytes(text.encode('utf-8'))
        for header in (ROOT/'src/aero').glob('*.hpp'):
            shutil.copyfile(header,case/header.name)
        obj = case / 'producer.obj'
        command = entry[0]['command']
        command = re.sub(r'/Fo\S+', lambda _: '/Fo' + str(obj).replace('\\', '/'), command)
        command = re.sub(r'/Fd\S+', lambda _: '/Fd' + str(case / 'producer.pdb').replace('\\', '/'), command)
        command = command.replace(str(SOURCE), str(source))
        result = {'name': name, 'source_sha256': sha(source), 'compile': call(command, BUILD, case / 'compile.log')}
        if result['compile']['exit'] != 0:
            raise RuntimeError(f'{name}: compile failed, not a kill')
        exe, map_path = case / 'test.exe', case / 'test.map'
        links = ['link', '/nologo', '/machine:x64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
                 '/OUT:' + str(exe), '/MAP:' + str(map_path), str(obj), str(snapshot / ('4-' + TESTOBJ.name)),
                 str(PREFIX / 'lib/manual-link/Catch2Main.lib'), str(snapshot / ('5-' + LIB.name)),
                 str(PREFIX / 'lib/Catch2.lib'), str(snapshot / ('6-' + CORE.name)), 'psapi.lib',
                 str(PREFIX / 'lib/boost_container-vc145-mt-x64-1_92.lib'),
                 str(PREFIX / 'lib/boost_random-vc145-mt-x64-1_92.lib'),
                 'kernel32.lib', 'user32.lib', 'gdi32.lib', 'winspool.lib', 'shell32.lib',
                 'ole32.lib', 'oleaut32.lib', 'uuid.lib', 'comdlg32.lib', 'advapi32.lib']
        result['link'] = call(links, BUILD, case / 'link.log')
        if result['link']['exit'] != 0:
            raise RuntimeError(f'{name}: link failed, not a kill')
        result['run'] = call([str(exe), '--rng-seed', '95'], case, case / 'run.log')
        mapping = map_path.read_text()
        result['original_producer_members_extracted'] = len(re.findall(r'uvlas_aero:geometry_snapshot', mapping))
        result['explicit_producer_symbols'] = len(re.findall(r'producer\.obj', mapping))
        result['input_hash_mismatches'] = sum(sha(p) != before[str(p)] for p in paths)
        results.append(result)
        (HERE / 'progress-byte-exact.json').write_text(json.dumps(results, indent=2))
        print(name, result['run']['exit'], flush=True)
    summary = {'inputs_before': before, 'inputs_after': {str(p): sha(p) for p in paths}, 'results': results}
    (HERE / 'summary-byte-exact.json').write_text(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
