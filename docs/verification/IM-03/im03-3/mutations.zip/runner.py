"""Private byte-preserving producer+test mutation runner; no shared source/build writes."""
from pathlib import Path
import ctypes
import hashlib
import json
import re
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BUILD=ROOT/'out/issue95-build'
PREFIX=Path('<dependency-workspace>/out/vcpkg_python_installed/x64-windows')
PRODUCERS=['src/aero/local_geometry_packet.cpp','src/aero/geometry_snapshot.cpp']
TEST='tests/aero/local_geometry_packet_test.cpp'
CASES=[
 ('control',None,None,None),
 ('discard_low_without_bound','src/aero/local_geometry_bounds_private.hpp',
  'low = floor_word(remainder, exponent - scale, consumed);','low = 0; consumed = remainder;'),
 ('discard_root_uncertainty','src/aero/local_geometry_bounds_private.hpp',
  'const bool uncertain = product != a;','const bool uncertain = false;'),
 ('radius_instead_of_full_width','src/aero/local_geometry_bounds_private.hpp',
  '2 * value.exponent() - 2146','2 * value.exponent() - 2148'),
 ('permit_free_contact','src/aero/local_geometry_packet.cpp','        if (on)\n','        if (false && on)\n'),
 ('permit_ideal_self','src/aero/local_geometry_packet.cpp','&& radius == 0)','&& radius < 0)'),
 ('ignore_snapshot_context','src/aero/geometry_snapshot.cpp',
  'data.identity != query.geometry_->identity || !same_context(context, query.context_)','false'),
]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def argv(command):
    parse=ctypes.windll.shell32.CommandLineToArgvW
    parse.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
    parse.restype=ctypes.POINTER(ctypes.c_wchar_p)
    n=ctypes.c_int();p=parse(command,ctypes.byref(n));result=[p[i] for i in range(n.value)]
    ctypes.windll.kernel32.LocalFree(p)
    return result

def call(args,cwd,log,timeout=180):
    start=time.monotonic()
    with log.open('wb') as stream:
        proc=subprocess.run(args,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    return {'exit':proc.returncode,'seconds':time.monotonic()-start}

def main():
    db=BUILD/'compile_commands.json'
    entries=json.loads(db.read_text(encoding='utf-8'))
    files=[ROOT/p for p in PRODUCERS+[TEST]]+sorted((ROOT/'src/aero').glob('*.hpp'))
    files += [ROOT/'tests/aero/geometry_snapshot_fixture.hpp',db,BUILD/'Release/uvlas_aero.lib',BUILD/'Release/uvlas_core.lib']
    before={str(p):sha(p) for p in files}
    snapshot=HERE/'snapshot-final';snapshot.mkdir(exist_ok=False)
    frozen=snapshot/'input';frozen.mkdir()
    for i,p in enumerate(files):shutil.copyfile(p,frozen/f'{i}-{p.name}')
    report={'inputs_before':before,'cases':[]}
    for name,target,old,new in CASES:
        folder=snapshot/name;folder.mkdir()
        for relative in PRODUCERS+[TEST,'tests/aero/geometry_snapshot_fixture.hpp']:
            destination=folder/relative;destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/relative,destination)
        for header in (ROOT/'src/aero').glob('*.hpp'):
            destination=folder/'src/aero'/header.name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(header,destination)
        if target:
            path=folder/target;original=path.read_bytes();text=original.decode('utf-8')
            if text.count(old)!=1:raise RuntimeError((name,'ambiguous anchor',text.count(old)))
            path.write_bytes(text.replace(old,new).encode('utf-8'))
        elif any(sha(folder/p)!=sha(ROOT/p) for p in PRODUCERS+[TEST]):
            raise RuntimeError('Control source bytes changed')
        item={'name':name,'compile':[]};objects=[]
        for i,relative in enumerate(PRODUCERS+[TEST]):
            expected=ROOT/relative
            selected=[e for e in entries if Path(e['file'])==expected and 'Release' in e['output'] and 'uvlas_aero_audit.dir' not in e['output']]
            if len(selected)!=1:raise RuntimeError((relative,len(selected)))
            args=argv(selected[0]['command']);obj=folder/f'producer-{i}.obj';objects.append(obj)
            args=[('/Fo'+str(obj)) if a.startswith('/Fo') else ('/Fd'+str(folder/f'producer-{i}.pdb')) if a.startswith('/Fd') else str(folder/relative) if Path(a)==expected else a for a in args]
            args.insert(1,'/I'+str(folder/'src'))
            result=call(args,BUILD,folder/f'compile-{i}.log');item['compile'].append(result)
            if result['exit']!=0:raise RuntimeError((name,'compile is not a kill',i))
        exe=folder/'test.exe';mapfile=folder/'test.map'
        link=['link','/nologo','/machine:x64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/OUT:'+str(exe),'/MAP:'+str(mapfile)]+list(map(str,objects))
        link += [str(PREFIX/'lib/manual-link/Catch2Main.lib'),str(BUILD/'Release/uvlas_aero.lib'),str(PREFIX/'lib/Catch2.lib'),str(BUILD/'Release/uvlas_core.lib'),'psapi.lib','kernel32.lib','user32.lib','gdi32.lib','winspool.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','advapi32.lib']
        item['link']=call(link,BUILD,folder/'link.log')
        if item['link']['exit']!=0:raise RuntimeError((name,'link is not a kill'))
        item['run']=call([str(exe),'--rng-seed','109'],folder,folder/'run.log',60)
        mapping=mapfile.read_text(encoding='utf-8',errors='replace')
        item['original_archive_producer_members_extracted']=len(re.findall(r'uvlas_aero:(?:local_geometry_packet|geometry_snapshot)\.cpp',mapping))
        item['explicit_producer_symbols']=len(re.findall(r'producer-[01]\.obj',mapping))
        item['input_hash_mismatches']=sum(sha(p)!=before[str(p)] for p in files)
        if item['original_archive_producer_members_extracted']!=0 or item['explicit_producer_symbols']==0 or item['input_hash_mismatches']!=0:raise RuntimeError('Producer or freeze proof failed')
        if (name=='control')!=(item['run']['exit']==0):raise RuntimeError((name,'wrong runtime outcome'))
        runtime=(folder/'run.log').read_text(encoding='utf-8',errors='replace')
        if name!='control' and not re.search(r'test cases:.*failed',runtime):raise RuntimeError((name,'not a Catch assertion kill'))
        item['runtime_failure_kind']='none' if name=='control' else 'Catch assertion'
        report['cases'].append(item);(HERE/'progress.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(name,item['run']['exit'],flush=True)
    report['inputs_after']={str(p):sha(p) for p in files}
    (HERE/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
