"""Compile isolated full-spectrum mutations against frozen Release inputs; never edits the source tree."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,time

parser=argparse.ArgumentParser()
parser.add_argument('--build',required=True)
parser.add_argument('--source-sha256',required=True)
args=parser.parse_args()
root=Path.cwd().resolve();build=(root/args.build).resolve();area=root/'out/issue68-peer-mutations'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
producer=root/'src/numerics/eigen_full.cpp'
if sha(producer)!=args.source_sha256:raise RuntimeError('source differs from supplied frozen hash')
snapshot=area/('snapshot-'+args.source_sha256[:12]);snapshot.mkdir(exist_ok=False)
frozen=snapshot/'inputs';frozen.mkdir()
inputs={}
def freeze(source,destination):
 if not source.is_file():raise RuntimeError('missing input '+str(source))
 before=sha(source);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination)
 if sha(source)!=before or sha(destination)!=before:raise RuntimeError('changed input '+str(source))
 inputs[str(source)]={'sha256':before,'snapshot':str(destination.relative_to(snapshot))}
for source in sorted((root/'include').rglob('*.hpp')):
 freeze(source,frozen/source.relative_to(root))
for source in sorted((root/'src/numerics').glob('*.hpp')):
 freeze(source,frozen/source.relative_to(root))
freeze(producer,frozen/'src/numerics/eigen_full.cpp')
for name in ['eigen_full_test.cpp','eigen_full_contract_test.cpp']:
 freeze(root/'tests/numerics'/name,frozen/'tests/numerics'/name)
fixture=root/'tests/numerics/fixtures/j1-pg-free-history-24-v1/fixture.json'
freeze(fixture,frozen/'fixture.json')
commands=json.loads((build/'compile_commands.json').read_text(encoding='utf-8-sig'))
entry=[x for x in commands if x['file'].replace('\\','/').endswith('/src/numerics/eigen_full.cpp') and '/Release/' in x['output'].replace('\\','/') and '_audit' not in x['output']]
if len(entry)!=1:raise RuntimeError(('expected unique Release producer entry',len(entry)))
entry=entry[0];freeze(build/'compile_commands.json',frozen/'compile_commands-all.json')
(frozen/'producer-command.json').write_text(json.dumps(entry,indent=2)+'\n',encoding='utf-8')
ninja=(build/'CMakeFiles/impl-Release.ninja').read_text(encoding='utf-8')
targets=[]
for case in ['eigen_full','eigen_full_contract']:
 target='uvlas_test_numerics_'+case
 obj=build/('tests/CMakeFiles/'+target+'.dir/Release/numerics/'+case+'_test.cpp.obj')
 copied=frozen/'objects'/(case+'.obj');freeze(obj,copied)
 block=re.search(r'build tests\\Release\\'+re.escape(target)+r'\.exe:.*?\n(?=build |\n\n)',ninja,re.S)
 if not block:raise RuntimeError('missing link block '+target)
 line=re.search(r'  LINK_LIBRARIES = ([^\n]+)',block[0])
 if not line:raise RuntimeError('missing link libraries '+target)
 tokens=line[1].split();libraries=[]
 for token in tokens:
  path=Path(token)
  if not path.is_absolute():path=build/path
  if path.is_file():
   dest=frozen/'libraries'/path.name
   if dest.exists():
    if sha(dest)!=sha(path):raise RuntimeError('library name collision '+str(path))
    inputs[str(path)]={'sha256':sha(path),'snapshot':str(dest.relative_to(snapshot))}
   else:freeze(path,dest)
   libraries.append(str(dest))
  else:libraries.append(token)
 targets.append({'name':case,'object':str(copied),'libraries':libraries})
(frozen/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
original=(frozen/'src/numerics/eigen_full.cpp').read_bytes()
mutations=[('control',None),
 ('right-exchange-disabled',(b'reorder(q, t, desired.values(), positions.values());',b'(void)q; (void)t; (void)desired; (void)positions;')),
 ('left-reuses-right-q',(b'import_basis(*data, leftq, leftt, true);',b'import_basis(*data, leftq, leftt, true); std::copy(data->right.values().begin(), data->right.values().end(), data->left.values().begin());')),
 ('last-consumer-unchecked',(b'i < r.consumers.size()',b'i + 1 < r.consumers.size()')),
 ('tiny-eigenvalue-clamped',(b'physical(i) = scaled(t(i, i), scales.eigenvalue_scale).value;',b'physical(i) = scaled(t(i, i), scales.eigenvalue_scale).value; if (std::abs(physical(i)) < 1e-12) physical(i) = Complex{};')),
 ('projected-forward-proof-reused',(b'd.basis = basis_gate(d, d.generation, false, action, error);',b'd.basis = d.retained_basis;'))]
report={'snapshot_source_sha256':args.source_sha256,'configuration':'Release','source_tree_modified':False,'results':[]}
def unchanged():
 for source,data in inputs.items():
  if sha(Path(source))!=data['sha256']:raise RuntimeError('live frozen input changed '+source)
def run(command,cwd,log,timeout=240):
 begun=time.monotonic();p=subprocess.run(command,cwd=cwd,capture_output=True,text=True,timeout=timeout)
 log.write_text(p.stdout+p.stderr,encoding='utf-8');return p.returncode,time.monotonic()-begun
for name,mutation in mutations:
 unchanged();case=snapshot/name;case.mkdir();source=original
 if mutation:
  before,after=mutation
  if source.count(before)!=1:raise RuntimeError((name,'mutation match count',source.count(before)))
  source=source.replace(before,after)
 path=case/'eigen_full.cpp';path.write_bytes(source)
 command=entry['command'].replace(entry['file'],str(path))
 for base in [str(root/'include'),str(root/'include').replace('\\','/')]:
  command=command.replace(base,str(frozen/'include'))
 command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(case/'producer.obj'),command,count=1)
 command=re.sub(r'/Fd\S+',lambda _: '/Fd'+str(case/'producer.pdb'),command,count=1)
 command+=' /I'+str(frozen/'src/numerics')
 (case/'compile-command.txt').write_text(command,encoding='utf-8')
 compile_exit,compile_seconds=run(command,build,case/'compile.log')
 result={'name':name,'source_sha256':sha(path),'compile_exit':compile_exit,'compile_seconds':compile_seconds,'targets':[]}
 print(json.dumps({'name':name,'compile_exit':compile_exit}),flush=True)
 if compile_exit:raise RuntimeError(result)
 env=dict(os.environ)
 # CMake's imported libraries are immutable; the matching DLL directory is selected explicitly.
 cache=(build/'CMakeCache.txt').read_text(encoding='utf-8')
 installed=re.search(r'^VCPKG_INSTALLED_DIR:[^=]+=(.+)$',cache,re.M)
 if not installed:raise RuntimeError('missing installed dependency directory')
 env['PATH']=str(Path(installed[1].strip())/'x64-windows/bin')+os.pathsep+env['PATH']
 for target in targets:
  label=target['name'];exe=case/(label+'.exe');map_path=case/(label+'.map')
  link=['link.exe','/nologo',target['object'],str(case/'producer.obj'),'/OUT:'+str(exe),'/MAP:'+str(map_path),'/PDB:'+str(case/(label+'.pdb')),'/INCREMENTAL:NO','/SUBSYSTEM:CONSOLE',*target['libraries']]
  (case/(label+'-link-command.json')).write_text(json.dumps(link,indent=2)+'\n',encoding='utf-8')
  link_exit,link_seconds=run(link,build,case/(label+'-link.log'))
  if link_exit:raise RuntimeError((name,label,'link failed',link_exit))
  text=map_path.read_text(encoding='utf-8')
  archive_matches=re.findall(r'uvlas_numerics[^\r\n]*[:(]eigen_full\.cpp\.obj',text,re.I)
  own=sum('full_spectrum' in line and 'producer.obj' in line for line in text.splitlines())
  if archive_matches or not own:raise RuntimeError((name,label,'producer extraction proof failed',len(archive_matches),own))
  begun=time.monotonic();executed=subprocess.run([str(exe),'--reporter','compact'],cwd=root,capture_output=True,text=True,env=env,timeout=60)
  output=executed.stdout+executed.stderr;(case/(label+'-run.log')).write_text(output,encoding='utf-8')
  result['targets'].append({'name':label,'link_exit':link_exit,'link_seconds':link_seconds,'run_exit':executed.returncode,'run_seconds':time.monotonic()-begun,'archive_producer_matches':len(archive_matches),'own_entry_symbols':own,'assertion_failure':executed.returncode!=0 and 'failed' in output.lower()})
  if name=='control' and executed.returncode:raise RuntimeError((name,label,'control failure',executed.returncode))
 killed=any(x['run_exit']!=0 and x['assertion_failure'] for x in result['targets'])
 if name!='control' and not killed:raise RuntimeError((name,'mutation survived',result['targets']))
 result['killed']=killed;report['results'].append(result);unchanged()
 (snapshot/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result),flush=True)
print(json.dumps({'snapshot':str(snapshot),'mutants_killed':sum(x['killed'] for x in report['results']),'control_passed':True}),flush=True)
