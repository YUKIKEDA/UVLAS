#pragma once

#define UVLAS_GIT_COMMIT "19221137cc86f2b0cc116cb048e0fe5b60d66ae5"
#define UVLAS_GIT_DIRTY 1
