"""Produce a separate redacted evidence bundle; original snapshot bytes stay immutable."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path.cwd().resolve()
area = root / 'out/issue77-rank-mutations'
snapshot = area / 'snapshot-906e008c866f-first'
destination = area / 'public-first'
destination.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
report = json.loads((snapshot / 'report.json').read_text(encoding='utf-8'))
inputs = json.loads((snapshot / 'inputs/inputs.json').read_text(encoding='utf-8'))
assert len(report['results']) == 3
assert report['results'][0]['run_exit'] == 0
assert all(x['compile_exit'] == x['link_exit'] == 0 for x in report['results'])
assert all(x['run_exit'] == 42 and x['killed'] for x in report['results'][1:])
assert all(sha((snapshot / v['snapshot']).read_bytes()) == v['sha256'] for v in inputs.values())
files = {snapshot / 'report.json', snapshot / 'inputs/inputs.json',
         area / 'run.py', area / 'agreed.json', Path(__file__).resolve()}
text_suffixes = {'.hpp', '.cpp', '.json', '.ninja', '.txt', '.py', '.md'}
files.update(p for p in (snapshot / 'inputs').rglob('*') if p.is_file() and p.suffix in text_suffixes)
for result in report['results']:
    case = snapshot / result['name']
    files.update(case / name for name in ['precision.cpp', 'compile-command.txt',
                  'compile.log', 'link-command.json', 'link.log', 'precision.map', 'run.log'])
    files.update(case / item['file'] for item in result['changed_files'])

policies = []
for path, replacement, label in [(str(root), '<repo>', 'repository-prefix'),
                                 ('<dependency-repo>', '<dependency-repo>', 'dependency-repository-prefix'),
                                 ('<user>', '<user>', 'user-directory-prefix')]:
    variants = {path, path.replace('\\', '/'), json.dumps(path)[1:-1],
                path.replace(':', '?3').replace('\\', '?2')}
    for spelling in sorted(variants, key=len, reverse=True):
        policies.append((re.compile(re.escape(spelling.encode()), re.I), replacement.encode(), label))
policies.append((re.compile(b'account', re.I), b'account', 'remaining-account-token'))
entries = []
archive = destination / 'mutations.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
    for path in sorted(files):
        original = path.read_bytes()
        derived = original
        replacements = {}
        for pattern, replacement, policy in policies:
            derived, count = pattern.subn(lambda _: replacement, derived)
            if count:
                replacements[policy] = replacements.get(policy, 0) + count
        assert b'account' not in derived.lower(), path
        assert b'<dependency-repo>' not in derived.lower(), path
        if path.is_relative_to(snapshot):
            name = 'snapshot/' + path.relative_to(snapshot).as_posix()
        else:
            name = 'runner/' + path.name
        bundle.writestr(name, derived)
        entries.append({'entry': name, 'raw_sha256': sha(original), 'published_sha256': sha(derived),
                        'raw_bytes': len(original), 'published_bytes': len(derived),
                        'replacements': replacements})
    manifest = {'kind': 'derived_public_evidence', 'source_sha256': report['snapshot_source_sha256'],
                'product_base_main': '19221137cc86f2b0cc116cb048e0fe5b60d66ae5',
                'test_sha256': sha((snapshot / 'inputs/tests/numerics/foundation_precision_rank_test.cpp').read_bytes()),
                'frozen_reference_sha256': sha((snapshot / 'inputs/rd/foundation/numerics/experiments/cpp-numerics/precision_hash.cpp').read_bytes()),
                'note': '新規rank参照testの未commit候補byteから作った隔離controlと2変異。clean製品認定とは呼ばない。既存precision.cppと固定test objectを使い、変異だけ専用producerへ入れた。通常/JSON/encoded filesystem prefixとaccount tokenだけを派生束で匿名化し、元rawと凍結R&D原本は変更しない。任意有理rankやTwoWord係数solverの実装完了は主張しない。',
                'control': {'cases': 2, 'assertions': 45, 'run_exit': 0},
                'mutants': 2, 'all_compile_link_success': True, 'mutant_assertion_exit': 42,
                'frozen_inputs': len(inputs), 'original_input_mismatches': 0,
                'archive_producer_matches': 0, 'map_files': 3,
                'excluded_binary_extensions': ['.obj', '.lib', '.exe', '.pdb'],
                'entry_count_excluding_this_manifest': len(entries), 'entries': entries}
    serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    assert b'account' not in serialized.lower()
    bundle.writestr('redaction.json', serialized)
(destination / 'redaction.json').write_bytes(serialized)
summary = {'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
           'redaction_sha256': sha(serialized), 'entry_count': len(entries) + 1,
           'raw_report_sha256': sha((snapshot / 'report.json').read_bytes()),
           'raw_runner_sha256': sha((area / 'run.py').read_bytes())}
(destination / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
