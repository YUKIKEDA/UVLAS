"""Copy-only directed sqrt endpoint mutations; no shared source or binary is changed."""
import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
root=Path.cwd();build=root/'out/issue70-release';area=root/'out/issue77-sqrt-mutations';frozen=area/'inputs';frozen.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={}
def copy(p,d):
 before=sha(p);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);assert sha(p)==sha(d)==before;inputs[str(p)]={'sha256':before,'copy':str(d.relative_to(area))}
copy(Path(__file__),frozen/'run.py')
source=root/'src/numerics/linear_metrics.cpp';copy(source,frozen/'linear_metrics.cpp')
for p in (root/'src/numerics').glob('*.hpp'):copy(p,frozen/'private'/p.name)
for p in (root/'include').rglob('*.hpp'):copy(p,frozen/'include'/p.relative_to(root/'include'))
copy(root/'tests/numerics/linear_metrics_test.cpp',frozen/'linear_metrics_test.cpp')
copy(build/'compile_commands.json',frozen/'compile_commands.json');copy(build/'build.ninja',frozen/'build.ninja')
db=json.loads((frozen/'compile_commands.json').read_text(encoding='utf-8-sig'))
def entry(suffix):
 found=[x for x in db if x['file'].replace('\\','/').endswith(suffix) and '_audit' not in x['output']];assert len(found)==1,found;return found[0]
producer_entry=entry('/src/numerics/linear_metrics.cpp');test_entry=entry('/tests/numerics/linear_metrics_test.cpp')
copy(build/test_entry['output'],frozen/'test.obj')
text=(frozen/'build.ninja').read_text();block=re.search(r'build tests[\\/]uvlas_test_numerics_linear_metrics\.exe:.*?\n(?=build |\n\n)',text,re.S);assert block
line=re.search(r'  LINK_LIBRARIES = ([^\n]+)',block[0]);assert line
libraries=[]
for token in line[1].split():
 p=Path(token);p=p if p.is_absolute() else build/p
 if p.is_file():copy(p,frozen/'libraries'/p.name);libraries.append(str(frozen/'libraries'/p.name))
 else:libraries.append(token)
(area/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
mutations=[('wrong-sqrt-direction','return adjacent(root, up);','return adjacent(root, !up);'),('inward-hypot-upper','return multiply_bound(scale, sqrt_bound(radicand, up), up);','const auto result = multiply_bound(scale, sqrt_bound(radicand, up), up);\n    return up && result > 0 ? adjacent(result, false) : result;')]
original=(frozen/'linear_metrics.cpp').read_text();assert all(original.count(old)==1 for _,old,_ in mutations)
(area/'mutations.json').write_text(json.dumps([{'name':n,'before':a,'after':b} for n,a,b in mutations],indent=2),encoding='utf-8')
def unchanged():assert all(sha(Path(p))==v['sha256'] for p,v in inputs.items())
def run(command,log,cwd=build,timeout=90):
 t=time.monotonic();r=subprocess.run(command,cwd=cwd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout);log.write_text(r.stdout+r.stderr,encoding='utf-8',newline='\n');return r.returncode,time.monotonic()-t,r.stdout+r.stderr
results=[]
for name,before,after in [('control','',''),*mutations]:
 unchanged();case=area/name;case.mkdir();
 for p in (frozen/'private').glob('*.hpp'):shutil.copy2(p,case/p.name)
 p=case/'linear_metrics.cpp';p.write_text(original.replace(before,after) if before else original,encoding='utf-8',newline='\n')
 command=producer_entry['command'].replace(producer_entry['file'],str(p))
 for orig,dest in [(root/'include',frozen/'include'),(root/'src/numerics',case)]:
  for spelling in [str(orig),str(orig).replace('\\','/')]:command=command.replace(spelling,str(dest))
 command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(case/'producer.obj'),command,count=1)
 command=re.sub(r'/Fd\S+',lambda _: '/Fd'+str(case/'producer.pdb'),command,count=1);command+=' /I'+str(case)
 (case/'compile-command.txt').write_text(command,encoding='utf-8')
 compile_exit,compile_seconds,_=run(command,case/'compile.log');assert compile_exit==0,(name,'compile is not kill',compile_exit)
 link=['link.exe','/nologo',str(frozen/'test.obj'),str(case/'producer.obj'),'/OUT:'+str(case/'test.exe'),'/MAP:'+str(case/'link.map'),'/PDB:'+str(case/'link.pdb'),'/INCREMENTAL:NO','/SUBSYSTEM:CONSOLE',*libraries]
 (case/'link-command.json').write_text(json.dumps(link,indent=2),encoding='utf-8');link_exit,_,_=run(link,case/'link.log');assert link_exit==0,(name,'link is not kill',link_exit)
 mapping=(case/'link.map').read_text();archive=re.findall(r'uvlas_numerics[^\r\n]*[:(]linear_metrics\.cpp\.obj',mapping,re.I);own=sum('actual_magnitude_bounds' in x and 'producer.obj' in x for x in mapping.splitlines());assert not archive and own
 runtime,seconds,output=run([str(case/'test.exe'),'256-bit*','--reporter','compact'],case/'run.log',root,30)
 killed=runtime!=0 and 'failed' in output.lower();assert runtime==0 if name=='control' else killed,(name,runtime)
 unchanged();result={'name':name,'changed_source_sha256':sha(p),'compile_exit':compile_exit,'compile_seconds':compile_seconds,'link_exit':link_exit,'run_exit':runtime,'seconds':seconds,'killed':killed,'original_archive_producer_members':len(archive),'explicit_producer_symbols':own,'frozen_inputs':len(inputs),'input_mismatches':0};results.append(result);(area/'report.json').write_text(json.dumps({'source_sha256':sha(source),'test_sha256':sha(root/'tests/numerics/linear_metrics_test.cpp'),'results':results},indent=2),encoding='utf-8');print(json.dumps(result),flush=True)
