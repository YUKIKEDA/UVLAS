#pragma once

#define UVLAS_GIT_COMMIT "c0dd4d61e804bd97f0a3618fa3b4c3a5b369554a"
#define UVLAS_GIT_DIRTY 0
