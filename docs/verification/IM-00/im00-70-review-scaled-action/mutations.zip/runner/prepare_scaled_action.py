"""Create the four agreed mutations from the fixed helper, without editing products."""
from pathlib import Path
import json
import re

area = Path('out/issue70-peer-mutations')
relative = Path('src/numerics/eigen_arnoldi_cluster.hpp')
current = relative.read_text(encoding='utf-8')
old = (area / 'snapshot-5ec906dacdc8-first/inputs' / relative).read_text(encoding='utf-8')
pattern = re.compile(r'\[\[nodiscard\]\] inline core::Result<void> arnoldi_scaled_action\([\s\S]*?^}', re.M)
before = list(pattern.finditer(current))
after = list(pattern.finditer(old))
assert len(before) == len(after) == 1

def mutation(name, source, target):
    assert current.count(source) == 1, (name, current.count(source))
    return {'name': name, 'edits': [{'file': relative.name, 'before': source, 'after': target}]}

mutations = [
    mutation('old-scaling-helper-restored', before[0][0], after[0][0]),
    mutation('conversion-width-discarded',
             'add_magnitudes({conversion_error, conversion_error}, {result->error, result->error});',
             'add_magnitudes({0.0, 0.0}, {result->error, result->error});'),
    mutation('producer-radius-discarded', 'total = add_magnitudes(total, producer);',
             'static_cast<void>(producer);'),
    mutation('sum-eft-error-discarded', '{result->error, result->error}', '{0.0, 0.0}')]
(area / 'scaled-action-agreed.json').write_bytes((json.dumps(mutations, indent=2) + '\n').encode())
print('four fixed-source mutation anchors unique; no product bytes modified')
