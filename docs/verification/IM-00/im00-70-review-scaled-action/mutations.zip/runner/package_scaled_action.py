"""Produce a separate redacted evidence bundle; original snapshot bytes stay immutable."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path.cwd().resolve()
area = root / 'out/issue70-peer-mutations'
snapshot = area / 'snapshot-5ec906dacdc8-scaled-action-fix'
destination = area / 'public-scaled-action-fix'
destination.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
report = json.loads((snapshot / 'report.json').read_text(encoding='utf-8'))
inputs = json.loads((snapshot / 'inputs/inputs.json').read_text(encoding='utf-8'))
assert len(report['results']) == 5
assert report['results'][0]['run_exit'] == 0
assert all(x['compile_exit'] == x['link_exit'] == 0 for x in report['results'])
assert all(x['test_compile_exit'] == 0 and x['test_private_headers_same_as_producer'] for x in report['results'])
assert all(x['run_exit'] == 42 and x['killed'] for x in report['results'][1:])
assert all(sha((snapshot / v['snapshot']).read_bytes()) == v['sha256'] for v in inputs.values())
files = {snapshot / 'report.json', snapshot / 'inputs/inputs.json',
         area / 'run_scaled_action.py', area / 'scaled-action-agreed.json',
         area / 'prepare_scaled_action.py', Path(__file__).resolve()}
text_suffixes = {'.hpp', '.cpp', '.json', '.ninja', '.txt', '.py', '.md'}
files.update(p for p in (snapshot / 'inputs').rglob('*') if p.is_file() and p.suffix in text_suffixes)
for result in report['results']:
    case = snapshot / result['name']
    files.update(case / name for name in ['eigen_arnoldi.cpp', 'eigen_arnoldi_test.cpp',
                  'compile-command.txt', 'compile.log', 'test-compile-command.txt', 'test-compile.log',
                  'link-command.json', 'link.log', 'eigen_arnoldi.map', 'run.log'])
    files.update(case / item['file'] for item in result['changed_files'])

policies = []
for path, replacement, label in [(str(root), '<repo>', 'repository-prefix'),
                                 ('<dependency-repo>', '<dependency-repo>', 'dependency-repository-prefix'),
                                 ('<user>', '<user>', 'user-directory-prefix')]:
    variants = {path, path.replace('\\', '/'), json.dumps(path)[1:-1],
                path.replace(':', '?3').replace('\\', '?2')}
    for spelling in sorted(variants, key=len, reverse=True):
        policies.append((re.compile(re.escape(spelling.encode()), re.I), replacement.encode(), label))
policies.append((re.compile(b'account', re.I), b'account', 'remaining-account-token'))
entries = []
archive = destination / 'mutations.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
    for path in sorted(files):
        original = path.read_bytes()
        derived = original
        replacements = {}
        for pattern, replacement, policy in policies:
            derived, count = pattern.subn(lambda _: replacement, derived)
            if count:
                replacements[policy] = replacements.get(policy, 0) + count
        assert b'account' not in derived.lower(), path
        assert b'<dependency-repo>' not in derived.lower(), path
        if path.is_relative_to(snapshot):
            name = 'snapshot/' + path.relative_to(snapshot).as_posix()
        else:
            name = 'runner/' + path.name
        bundle.writestr(name, derived)
        entries.append({'entry': name, 'raw_sha256': sha(original), 'published_sha256': sha(derived),
                        'raw_bytes': len(original), 'published_bytes': len(derived),
                        'replacements': replacements})
    manifest = {'kind': 'derived_public_evidence', 'source_sha256': report['snapshot_source_sha256'],
                'snapshot_source_commit': 'c0dd4d61e804bd97f0a3618fa3b4c3a5b369554a',
                'scaled_action_header_sha256': sha((snapshot / 'inputs/src/numerics/eigen_arnoldi_cluster.hpp').read_bytes()),
                'test_sha256': sha((snapshot / 'inputs/tests/numerics/eigen_arnoldi_test.cpp').read_bytes()),
                'note': '修正helperのclean snapshotからproducer/test両TUを同じprivate copyで再compileした。既存の23case/625assertと5変異の束は変更しない。通常/JSON/encoded filesystem prefixとaccount tokenだけを派生束で匿名化し、元rawは変更しない。',
                'control': {'cases': 26, 'assertions': 835, 'run_exit': 0},
                'mutants': 4, 'all_compile_link_success': True, 'both_translation_units_recompiled': True,
                'mutant_assertion_exit': 42,
                'frozen_inputs': len(inputs), 'original_input_mismatches': 0,
                'archive_producer_matches': 0, 'map_files': 5,
                'excluded_binary_extensions': ['.obj', '.lib', '.exe', '.pdb'],
                'entry_count_excluding_this_manifest': len(entries), 'entries': entries}
    serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    assert b'account' not in serialized.lower()
    bundle.writestr('redaction.json', serialized)
(destination / 'redaction.json').write_bytes(serialized)
summary = {'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
           'redaction_sha256': sha(serialized), 'entry_count': len(entries) + 1,
           'raw_report_sha256': sha((snapshot / 'report.json').read_bytes()),
           'raw_runner_sha256': sha((area / 'run_scaled_action.py').read_bytes())}
(destination / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
