"""Isolate inline scaled-action mutations in both producer and test translation units."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--build', required=True)
parser.add_argument('--configuration', choices=['Debug', 'Release'], required=True)
parser.add_argument('--source-sha256', required=True)
parser.add_argument('--mutations', required=True)
parser.add_argument('--label', default='first')
args = parser.parse_args()
root = Path.cwd().resolve()
build = (root / args.build).resolve()
area = root / 'out/issue70-peer-mutations'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
producer = root / 'src/numerics/eigen_arnoldi.cpp'
if sha(producer) != args.source_sha256:
    raise RuntimeError('source differs from explicitly supplied frozen hash')
if not re.fullmatch(r'[a-zA-Z0-9_-]+', args.label):
    raise RuntimeError('label must be a simple name')
mutation_path = (root / args.mutations).resolve()
mutations = json.loads(mutation_path.read_text(encoding='utf-8-sig'))
if not 1 <= len(mutations) <= 5:
    raise RuntimeError('agree one to five meaningful mutations before executing')
snapshot = area / ('snapshot-' + args.source_sha256[:12] + '-' + args.label)
snapshot.mkdir(exist_ok=False)
frozen = snapshot / 'inputs'
frozen.mkdir()
inputs = {}

def freeze(source, destination):
    if not source.is_file():
        raise RuntimeError('missing frozen input ' + str(source))
    before = sha(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    if sha(source) != before or sha(destination) != before:
        raise RuntimeError('input changed while copying ' + str(source))
    inputs[str(source)] = {'sha256': before, 'snapshot': str(destination.relative_to(snapshot))}

freeze(Path(__file__).resolve(), frozen / 'run.py')
freeze(mutation_path, frozen / 'mutations.json')
for source in sorted((root / 'include').rglob('*.hpp')):
    freeze(source, frozen / source.relative_to(root))
for source in sorted((root / 'src/numerics').glob('*.hpp')):
    freeze(source, frozen / source.relative_to(root))
freeze(producer, frozen / 'src/numerics/eigen_arnoldi.cpp')
test_source = root / 'tests/numerics/eigen_arnoldi_test.cpp'
freeze(test_source, frozen / test_source.relative_to(root))
for source in sorted((root / 'tests/numerics/fixtures/j1-pg-free-history-24-v1').rglob('*')):
    if source.is_file():
        freeze(source, frozen / source.relative_to(root))
if (build / 'generated').exists():
    for source in sorted((build / 'generated').rglob('*')):
        if source.is_file():
            freeze(source, frozen / 'generated' / source.relative_to(build / 'generated'))
freeze(build / 'compile_commands.json', frozen / 'compile_commands.json')
commands = json.loads((frozen / 'compile_commands.json').read_text(encoding='utf-8-sig'))

def command_for(filename):
    found = [x for x in commands if x['file'].replace('\\', '/').endswith('/' + filename)
             and '_audit' not in x['output']]
    configured = [x for x in found if '/' + args.configuration + '/' in x['output'].replace('\\', '/')]
    if configured:
        found = configured
    if len(found) != 1:
        raise RuntimeError(('expected unique compile command', filename, len(found)))
    return found[0]

entry = command_for('src/numerics/eigen_arnoldi.cpp')
test_entry = command_for('tests/numerics/eigen_arnoldi_test.cpp')
test_object = build / test_entry['output']
freeze(test_object, frozen / 'eigen_arnoldi_test.obj')
ninja = build / ('CMakeFiles/impl-' + args.configuration + '.ninja')
if not ninja.exists():
    ninja = build / 'build.ninja'
freeze(ninja, frozen / 'link-input.ninja')
ninja_text = (frozen / 'link-input.ninja').read_text(encoding='utf-8')
target = 'uvlas_test_numerics_eigen_arnoldi'
block = re.search(r'build tests[\\/](?:' + args.configuration + r'[\\/])?' + target
                  + r'\.exe:.*?\n(?=build |\n\n)', ninja_text, re.S)
if not block:
    raise RuntimeError('missing target link block')
library_line = re.search(r'  LINK_LIBRARIES = ([^\n]+)', block[0])
if not library_line:
    raise RuntimeError('missing target link libraries')
libraries = []
for token in library_line[1].split():
    path = Path(token)
    if not path.is_absolute():
        path = build / path
    if path.is_file():
        destination = frozen / 'libraries' / path.name
        if destination.exists() and sha(destination) != sha(path):
            raise RuntimeError('library filename collision ' + str(path))
        freeze(path, destination)
        libraries.append(str(destination))
    else:
        libraries.append(token)
freeze(build / 'CMakeCache.txt', frozen / 'CMakeCache.txt')
(frozen / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8')
cache = (frozen / 'CMakeCache.txt').read_text(encoding='utf-8')
if not re.search(r'^CMAKE_CONFIGURATION_TYPES:[^=]+=.+$', cache, re.M):
    configured = re.search(r'^CMAKE_BUILD_TYPE:[^=]+=(.*)$', cache, re.M)
    if configured is None or configured[1].strip() != args.configuration:
        raise RuntimeError('single-config build does not match the requested configuration')
installed = re.search(r'^VCPKG_INSTALLED_DIR:[^=]+=(.+)$', cache, re.M)
if not installed:
    raise RuntimeError('missing installed dependency directory')
env = dict(os.environ)
dll = Path(installed[1].strip()) / 'x64-windows'
env['PATH'] = str(dll / ('debug/bin' if args.configuration == 'Debug' else 'bin')) + os.pathsep + env['PATH']
report = {'snapshot_source_sha256': args.source_sha256, 'configuration': args.configuration,
          'source_tree_modified': False, 'results': []}

def unchanged():
    for original, data in inputs.items():
        if sha(Path(original)) != data['sha256']:
            raise RuntimeError('frozen live input changed ' + original)

def execute(command, cwd, log, timeout=300):
    begun = time.monotonic()
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    log.write_text(result.stdout + result.stderr, encoding='utf-8')
    return result.returncode, time.monotonic() - begun, result.stdout + result.stderr

for mutation in [{'name': 'control', 'edits': []}, *mutations]:
    unchanged()
    name = mutation['name']
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', name):
        raise RuntimeError('unsafe mutation name')
    case = snapshot / name
    case.mkdir()
    # Every private header is copied per case so nested quoted includes cannot
    # bypass an overridden header through the shared frozen header directory.
    for header in (frozen / 'src/numerics').glob('*.hpp'):
        shutil.copy2(header, case / header.name)
    shutil.copy2(frozen / 'src/numerics/eigen_arnoldi.cpp', case / 'eigen_arnoldi.cpp')
    shutil.copy2(frozen / test_source.relative_to(root), case / 'eigen_arnoldi_test.cpp')
    changed = []
    for edit in mutation['edits']:
        path = case / edit['file']
        if path.parent != case or not path.is_file():
            raise RuntimeError('mutation must target a copied producer/private header')
        content = path.read_bytes()
        before, after = edit['before'].encode(), edit['after'].encode()
        if b'\r\n' in content and b'\r' not in before:
            before, after = before.replace(b'\n', b'\r\n'), after.replace(b'\n', b'\r\n')
        if content.count(before) != 1:
            raise RuntimeError((name, edit['file'], 'anchor count', content.count(before)))
        path.write_bytes(content.replace(before, after))
        changed.append({'file': edit['file'], 'sha256': sha(path)})
    command = entry['command'].replace(entry['file'], str(case / 'eigen_arnoldi.cpp'))
    for original, destination in [(root / 'include', frozen / 'include'),
                                   (build / 'generated', frozen / 'generated'),
                                   (root / 'src/numerics', case)]:
        for spelling in [str(original), str(original).replace('\\', '/')]:
            command = command.replace(spelling, str(destination))
    command = re.sub(r'/Fo\S+', lambda _: '/Fo' + str(case / 'producer.obj'), command, count=1)
    command = re.sub(r'/Fd\S+', lambda _: '/Fd' + str(case / 'producer.pdb'), command, count=1)
    command += ' /I' + str(case)
    (case / 'compile-command.txt').write_text(command, encoding='utf-8')
    compile_exit, compile_seconds, _ = execute(command, build, case / 'compile.log')
    print(json.dumps({'name': name, 'compile_exit': compile_exit}), flush=True)
    if compile_exit:
        raise RuntimeError((name, 'compile failure is not a killed mutation', compile_exit))
    # The oracle directly invokes this inline private helper. Reusing a test
    # object compiled with the normal header could bypass the mutated body or
    # mix COMDAT definitions, even while the producer object is correct.
    test_command = test_entry['command'].replace(test_entry['file'], str(case / 'eigen_arnoldi_test.cpp'))
    for original, destination in [(root / 'include', frozen / 'include'),
                                   (build / 'generated', frozen / 'generated'),
                                   (root / 'src/numerics', case)]:
        for spelling in [str(original), str(original).replace('\\', '/')]:
            test_command = test_command.replace(spelling, str(destination))
    test_command = re.sub(r'/Fo\S+', lambda _: '/Fo' + str(case / 'test.obj'), test_command, count=1)
    test_command = re.sub(r'/Fd\S+', lambda _: '/Fd' + str(case / 'test.pdb'), test_command, count=1)
    test_command += ' /I' + str(case)
    (case / 'test-compile-command.txt').write_text(test_command, encoding='utf-8')
    test_compile_exit, test_compile_seconds, _ = execute(test_command, build, case / 'test-compile.log')
    print(json.dumps({'name': name, 'test_compile_exit': test_compile_exit}), flush=True)
    if test_compile_exit:
        raise RuntimeError((name, 'test compile failure is not a killed mutation', test_compile_exit))
    map_path = case / 'eigen_arnoldi.map'
    executable = case / 'eigen_arnoldi.exe'
    link = ['link.exe', '/nologo', str(case / 'test.obj'), str(case / 'producer.obj'),
            '/OUT:' + str(executable), '/MAP:' + str(map_path), '/PDB:' + str(case / 'linked.pdb'),
            '/INCREMENTAL:NO', '/SUBSYSTEM:CONSOLE', *libraries]
    (case / 'link-command.json').write_text(json.dumps(link, indent=2) + '\n', encoding='utf-8')
    link_exit, link_seconds, _ = execute(link, build, case / 'link.log')
    if link_exit:
        raise RuntimeError((name, 'link failure is not a killed mutation', link_exit))
    map_text = map_path.read_text(encoding='utf-8')
    archive = re.findall(r'uvlas_numerics[^\r\n]*[:(]eigen_arnoldi\.cpp\.obj', map_text, re.I)
    own = sum('arnoldi_spectrum' in line and 'producer.obj' in line for line in map_text.splitlines())
    if archive or not own:
        raise RuntimeError((name, 'producer link-map proof failed', len(archive), own))
    runtime, seconds, output = execute([str(executable), '--reporter', 'compact'], root, case / 'run.log', 60)
    killed = runtime != 0 and 'failed' in output.lower()
    if name == 'control' and runtime:
        raise RuntimeError(('control failed', runtime))
    if name != 'control' and not killed:
        raise RuntimeError((name, 'mutation survived or did not assert', runtime))
    unchanged()
    report['results'].append({'name': name, 'changed_files': changed, 'compile_exit': compile_exit,
                             'compile_seconds': compile_seconds,
                             'test_compile_exit': test_compile_exit, 'test_compile_seconds': test_compile_seconds,
                             'test_private_headers_same_as_producer': True, 'link_exit': link_exit,
                             'link_seconds': link_seconds, 'run_exit': runtime, 'run_seconds': seconds,
                             'archive_producer_matches': len(archive), 'own_entry_symbols': own,
                             'killed': killed, 'frozen_input_count': len(inputs), 'input_mismatches': 0})
    (snapshot / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report['results'][-1]), flush=True)
print(json.dumps({'snapshot': str(snapshot), 'control_passed': True,
                  'mutants_killed': sum(x['killed'] for x in report['results'])}), flush=True)
