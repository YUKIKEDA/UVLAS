from pathlib import Path
import hashlib, json, os, re, shlex, shutil, subprocess, time

OWNER = Path('<repo>')
WORK = Path(__file__).resolve().parent
BUILD = OWNER / 'out/build/python-msvc'
INPUTS = WORK / 'inputs'
INPUTS.mkdir()
FILES, RESULTS = {}, []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(source, target):
    before = source.stat()
    raw = source.read_bytes()
    after = source.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), source
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    assert sha(source) == sha(target), source
    FILES[str(source)] = {'snapshot': str(target), 'sha256': sha(target)}
    return target

for source in (OWNER / 'include').rglob('*.hpp'):
    snapshot(source, INPUTS / 'include' / source.relative_to(OWNER / 'include'))
for source in (OWNER / 'src/numerics').glob('*.hpp'):
    snapshot(source, INPUTS / 'private' / source.name)
snapshot(OWNER / 'src/numerics/eigen_metrics.cpp', INPUTS / 'original.cpp')
snapshot(OWNER / 'tests/numerics/eigen_metrics_test.cpp', INPUTS / 'test.cpp')
assert sha(INPUTS / 'original.cpp') == 'b9fc0ff4fd0b429c6f6a23a418ece80d709cee83b67851bd23d864a54e322e98'
assert sha(INPUTS / 'test.cpp') == '22ce3347abc5e02b12af36e0d1b36e7251a5101a52fb1447816355c8623a57b5'
assert sha(INPUTS / 'private/eigen_metric_bounds.hpp') == '138ee948601460dc338665f6aa8d1251dbbd41ad3ecb973efd9515e948ca33d5'
DB = json.loads((BUILD / 'compile_commands.json').read_text())
ENTRY = next(item for item in DB if item['file'].replace('\\', '/').endswith('/eigen_metrics.cpp')
             and 'Release' in item['command'] and 'uvlas_numerics.dir' in item['command'])
output = subprocess.run(['ninja', '-f', 'build-Release.ninja', '-t', 'commands',
                         'uvlas_test_numerics_eigen_metrics'], cwd=BUILD,
                        capture_output=True, text=True, check=True, timeout=30).stdout
line = next(line for line in output.splitlines() if 'link.exe' in line and 'vs_link_exe' in line)
LINK = [part.strip('"') for part in shlex.split(line.split(' -- ', 1)[1].split(' && ', 1)[0], posix=False)]
binary_directories = set()
for index, value in enumerate(LINK):
    if value.lower().endswith(('.lib', '.obj')):
        source = Path(value)
        if not source.is_absolute():
            source = BUILD / source
        if source.is_file():
            LINK[index] = str(snapshot(source, INPUTS / 'link' / source.name))
            for parent in source.parents:
                if parent.name == 'lib' and (parent.parent / 'bin').is_dir():
                    binary_directories.add(parent.parent / 'bin')
for directory in binary_directories:
    for source in directory.glob('*.dll'):
        target = INPUTS / 'bin' / source.name
        if target.exists():
            assert sha(target) == sha(source)
        else:
            snapshot(source, target)
ENV = os.environ.copy()
ENV['PATH'] = str(INPUTS / 'bin') + os.pathsep + ENV['PATH']
ORIGINAL = (INPUTS / 'original.cpp').read_text()
VARIANTS = {'control': ORIGINAL}
patches = {
 'drop-low-words': [('return view.low().empty() ? Scalar{} : view.low()[index];',
                    'return view.low().empty() ? Scalar{} : view.low()[index] * Scalar{0};')],
 'drop-producer-error': [('residual_upper(detail::Sum<Scalar>& sum, double action_error) noexcept {',
                         'residual_upper(detail::Sum<Scalar>& sum, double action_error) noexcept {\n    action_error *= 0;')],
 'bypass-gram-rank': [('if (k != 0 && !(gram < 1))\n                return fail(context, FailureCode::RankUnresolved);', ''),
                      ('if (n != 0 && !(gram < 1))\n                return fail(context, FailureCode::RankUnresolved);', '')],
 'bypass-required-beta': [('if (!required)\n        return BackwardCertificate{NotRequested{}};',
                         'if (!required || request.index() == 1)\n        return BackwardCertificate{NotRequested{}};')]
}
for name, changes in patches.items():
    text = ORIGINAL
    for before, after in changes:
        assert text.count(before) == 1, (name, before)
        text = text.replace(before, after)
    VARIANTS[name] = text
for name, text in VARIANTS.items():
    target = WORK / name
    target.mkdir()
    for header in (INPUTS / 'private').glob('*.hpp'):
        shutil.copy2(header, target / header.name)
    cpp, obj = target / 'metric.cpp', target / 'metric.obj'
    cpp.write_text(text, newline='\n')
    command = ENTRY['command'].replace(ENTRY['file'], '"' + str(cpp) + '"')
    command = command.replace(str(OWNER / 'include'), str(INPUTS / 'include'))
    command = command.replace(str(OWNER / 'src/numerics'), str(target))
    command = re.sub(r'/Fo[^ ]+', lambda _: '/Fo"' + str(obj) + '"', command, count=1)
    command = re.sub(r'/Fd[^ ]+', lambda _: '/Fd"' + str(target / 'compile.pdb') + '"', command, count=1)
    assert str(OWNER / 'include') not in command and str(OWNER / 'src/numerics') not in command
    start = time.time()
    compiled = subprocess.run(command, cwd=target, env=ENV, capture_output=True, text=True, timeout=120)
    (target / 'compile.log').write_text(compiled.stdout + compiled.stderr, newline='\n')
    assert compiled.returncode == 0, (name, compiled.stdout, compiled.stderr)
    linked = LINK.copy()
    linked.insert(1, str(obj))
    for index, value in enumerate(linked):
        for option, destination in [('/out:', target / 'runner.exe'), ('/implib:', target / 'runner.lib'), ('/pdb:', target / 'link.pdb')]:
            if value.lower().startswith(option):
                linked[index] = option + str(destination)
    linked.append('/MAP:' + str(target / 'link.map'))
    process = subprocess.run(linked, cwd=target, env=ENV, capture_output=True, text=True, timeout=30)
    (target / 'link.log').write_text(process.stdout + process.stderr, newline='\n')
    assert process.returncode == 0, (name, process.stdout, process.stderr)
    assert ':eigen_metrics.cpp.obj' not in (target / 'link.map').read_text()
    args = [str(target / 'runner.exe'), '--reporter', 'compact', '--rng-seed', '424242']
    tested = subprocess.run(args, cwd=target, env=ENV, capture_output=True, text=True, timeout=30)
    (target / 'test.log').write_text(tested.stdout + tested.stderr, newline='\n')
    RESULTS.append({'variant': name, 'patches': patches.get(name, []), 'compile_command': command,
        'link_command': linked, 'test_command': args, 'compile_exit': compiled.returncode,
        'link_exit': process.returncode, 'test_exit': tested.returncode,
        'source_sha256': sha(cpp), 'test_log_sha256': sha(target / 'test.log'),
        'link_map_sha256': sha(target / 'link.map'), 'no_original_metric_archive_member': True,
        'started_unix': start, 'finished_unix': time.time()})
    (WORK / 'results.json').write_text(json.dumps({'metric_source_commit': 'eb3ec4d1f123f4ede154012cb2e994b1339a687e',
        'header_note': 'Final root private header additionally removes one unused divide wrapper; snapshot hash recorded.',
        'timeouts_seconds': {'compile': 120, 'link': 30, 'test': 30}, 'inputs': FILES, 'results': RESULTS}, indent=2), newline='\n')
    print(name, 'test exit', tested.returncode, flush=True)
    print('\n'.join(tested.stdout.splitlines()[-5:]), flush=True)
    assert tested.returncode == (0 if name == 'control' else 42), (name, tested.returncode)
changed = [source for source, item in FILES.items() if sha(Path(source)) != item['sha256']]
(WORK / 'owner-after.json').write_text(json.dumps({'changed_after_snapshot': changed}, indent=2), newline='\n')
print('inputs', len(FILES), 'changed', changed, flush=True)
