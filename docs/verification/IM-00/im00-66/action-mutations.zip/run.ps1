$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$source=Join-Path $PSScriptRoot 'snapshot/eigen_action.cpp'
$original=[IO.File]::ReadAllBytes($source)
$originalText=[Text.Encoding]::UTF8.GetString($original)
$records=@()
$variants=@(
    @{ name='control'; old=''; replacement='' },
    @{ name='discard-low-plane'; old='return provider.apply(kind, input, high, low, error_upper);'; replacement='auto dropped = WordView<Scalar>::make(input.high(), {}, core::Precision::Binary64); return provider.apply(kind, *dropped, high, low, error_upper);' },
    @{ name='omit-low-sentinel'; old='std::fill(low.begin(), low.end(), sentinel);'; replacement='/* mutant: preserve stale trailing output */' },
    @{ name='allow-excess-action'; old='if (**count >= limit) {'; replacement='if (**count > limit) {' }
)
& "$root/tools/dev/msvc.ps1" cmake -S $PSScriptRoot -B "$PSScriptRoot/build" -G 'Ninja Multi-Config' '-DCMAKE_PREFIX_PATH=<repo>/out/vcpkg_installed/x64-windows' *> "$PSScriptRoot/configure.log"
if ($LASTEXITCODE -ne 0) {throw 'configure failed'}
foreach($variant in $variants) {
    $candidate=$originalText
    if ($variant.name -ne 'control') {
        if (([regex]::Matches($candidate,[regex]::Escape($variant.old))).Count -ne 1) {throw "Expected one mutation site: $($variant.name)"}
        $candidate=$candidate.Replace($variant.old,$variant.replacement)
    }
    [IO.File]::WriteAllText($source,$candidate,[Text.UTF8Encoding]::new($false))
    & "$root/tools/dev/msvc.ps1" cmake --build "$PSScriptRoot/build" --config Release --target probe *> "$PSScriptRoot/$($variant.name)-build.log"
    $build=$LASTEXITCODE
    if ($build -ne 0) {throw "mutation did not compile: $($variant.name)"}
    $process=Start-Process -FilePath "$PSScriptRoot/build/Release/probe.exe" -ArgumentList '--reporter','console' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/$($variant.name)-test.log" -RedirectStandardError "$PSScriptRoot/$($variant.name)-stderr.log"
    if (-not $process.WaitForExit(30000)) {$process.Kill();throw 'test exceeded 30 sec'}
    $exitCode=$process.ExitCode
    $records+=@{name=$variant.name;build=$build;test=$exitCode}
    if (($variant.name -eq 'control' -and $exitCode -ne 0) -or ($variant.name -ne 'control' -and $exitCode -eq 0)) {throw "unexpected test result: $($variant.name)"}
}
[IO.File]::WriteAllBytes($source,$original)
$records | ConvertTo-Json | Set-Content -LiteralPath "$PSScriptRoot/results.json" -Encoding utf8
$records | ConvertTo-Json
