from pathlib import Path
import hashlib,json,re,subprocess,os
root=Path.cwd(); build=root/'out/issue69-msvc'; area=root/'out/issue69-mutants'
entries=json.loads((root/'out/issue69-tidy/compile_commands.json').read_text(encoding='utf-8-sig'))
entry=next(x for x in entries if x['file'].endswith('eigen_generalized.cpp'))
original=(root/'src/numerics/eigen_generalized.cpp').read_bytes()
paths=['src/numerics/eigen_generalized.cpp','include/uvlas/numerics/eigen_generalized.hpp','tests/numerics/eigen_generalized_test.cpp','include/uvlas/numerics/eigen_metrics.hpp']
inputs={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
mutations={'control':None,
 'tiny-clamp':(b'work->values.values()[static_cast<std::size_t>(column)] = *value;',b'work->values.values()[static_cast<std::size_t>(column)] = std::abs(*value)<1.e-12 ? 0 : *value;'),
 'mass-proof-bypass':(b'if (!qualification->certified || !qualification->shift.has_value())',b'if (false)'),
 'consumer-first-only':(b'i < request.precision.required_checks.size()',b'i < std::min(request.precision.required_checks.size(), std::size_t{1})'),
 'quota-extra-call':(b'if (started >= limit)',b'if (started > limit)')}
report={'source_sha256':hashlib.sha256(original).hexdigest(),'inputs':inputs,'results':[]}
libs=root/'out/vcpkg_installed/x64-windows/debug/lib'
objects=[build/'tests/CMakeFiles/uvlas_test_numerics_eigen_generalized.dir/Debug/numerics/eigen_generalized_test.cpp.obj']
linklibs=[libs/'manual-link/Catch2Maind.lib',build/'Debug/uvlas_numerics.lib',libs/'Catch2d.lib',build/'Debug/uvlas_core.lib',libs/'boost_container-vc145-mt-gd-x64-1_92.lib',libs/'boost_random-vc145-mt-gd-x64-1_92.lib']
env=dict(os.environ);env['PATH']=str(root/'out/vcpkg_installed/x64-windows/debug/bin')+os.pathsep+env['PATH']
for name,mutation in mutations.items():
 dest=area/name;dest.mkdir(exist_ok=True);source=original
 if mutation:
  a,b=mutation
  if source.count(a)!=1:raise RuntimeError((name,source.count(a)))
  source=source.replace(a,b)
 (dest/'eigen_generalized.cpp').write_bytes(source)
 command=entry['command'].replace(entry['file'],str(dest/'eigen_generalized.cpp'))
 command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(dest/'mutant.obj'),command,count=1)
 command=re.sub(r'/Fd\S+',lambda _: '/Fd'+str(dest/'compile.pdb'),command,count=1)
 command+=' /I'+str(root/'src/numerics')
 (dest/'command.txt').write_text(command,encoding='utf-8')
 compiled=subprocess.run(command,cwd=build,capture_output=True,text=True)
 (dest/'compile.log').write_text(compiled.stdout+compiled.stderr,encoding='utf-8')
 record={'name':name,'compile_exit':compiled.returncode,'mutant_sha256':hashlib.sha256(source).hexdigest()}
 if compiled.returncode:raise RuntimeError(record)
 executable=dest/'check.exe'
 link=['link.exe','/nologo',*(str(x) for x in objects),str(dest/'mutant.obj'),'/OUT:'+str(executable),'/PDB:'+str(dest/'check.pdb'),'/MAP:'+str(dest/'check.map'),'/DEBUG','/INCREMENTAL:NO','/SUBSYSTEM:CONSOLE',*(str(x) for x in linklibs),'psapi.lib','kernel32.lib','user32.lib','advapi32.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','gdi32.lib','winspool.lib']
 linked=subprocess.run(link,cwd=build,capture_output=True,text=True)
 (dest/'link.log').write_text(linked.stdout+linked.stderr,encoding='utf-8');record['link_exit']=linked.returncode
 if linked.returncode:raise RuntimeError(record)
 run=subprocess.run([str(executable),'--reporter','compact'],cwd=dest,capture_output=True,text=True,env=env)
 (dest/'run.log').write_text(run.stdout+run.stderr,encoding='utf-8');record['run_exit']=run.returncode
 if (name=='control') != (run.returncode==0):raise RuntimeError(record)
 report['results'].append(record);print(json.dumps(record),flush=True)
 for path,expected in inputs.items():
  if hashlib.sha256((root/path).read_bytes()).hexdigest()!=expected:raise RuntimeError('changed input '+path)
(area/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
