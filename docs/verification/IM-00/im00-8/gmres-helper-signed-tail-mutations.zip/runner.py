from pathlib import Path
import hashlib,json,os,re,shlex,shutil,subprocess,sys,time

owner=Path('<repo>')
work=Path.cwd()/'out/gmres-helper-review'
build=owner/'out/build/windows-msvc'
inputs=work/'inputs';inputs.mkdir()
files={}
def snapshot(source,destination):
    before=source.stat();raw=source.read_bytes();after=source.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),source
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(raw)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==hashlib.sha256(raw).hexdigest(),source
    files[str(source)]={'snapshot':str(destination),'sha256':hashlib.sha256(raw).hexdigest()}
    return destination
headers=inputs/'include'
for source in (owner/'include').rglob('*.hpp'):
    snapshot(source,headers/source.relative_to(owner/'include'))
private=inputs/'private'
for name in ('gmres_residual_detail.hpp','compensated.hpp','linear_solve_detail.hpp'):
    snapshot(owner/'src/numerics'/name,private/name)
source=owner/'src/numerics/gmres_residual_detail.cpp'
snapshot(source,inputs/'original.cpp')
snapshot(owner/'tests/numerics/gmres_residual_test.cpp',inputs/'test.cpp')
db=json.loads((build/'compile_commands.json').read_text())
entry=next(e for e in db if e['file'].replace('\\','/').endswith('/gmres_residual_detail.cpp') and 'Release' in e['command'] and 'uvlas_numerics.dir' in e['command'])
original_compile=entry['command']
command_dump=subprocess.run(['ninja','-f','build-Release.ninja','-t','commands','uvlas_test_numerics_gmres_residual'],cwd=build,capture_output=True,text=True,check=True,timeout=30).stdout
link_line=next(line for line in command_dump.splitlines() if 'link.exe' in line and 'vs_link_exe' in line)
link_text=link_line.split(' -- ',1)[1].split(' && ',1)[0]
link_template=[part.strip('"') for part in shlex.split(link_text,posix=False)]
# Keep each borrowed ABI artifact in the snapshot, never relink against changing owner outputs.
for i,token in enumerate(link_template):
    if token.lower().endswith(('.lib','.obj')):
        source_path=Path(token)
        if not source_path.is_absolute():source_path=build/source_path
        if source_path.is_file():
            destination=inputs/'link'/source_path.name
            link_template[i]=str(snapshot(source_path,destination))
# Runtime dependencies are copied too; system CRT/OS DLLs retain the initialized MSVC environment.
prefix=Path('<repo>/out/vcpkg_installed/x64-windows/bin')
for dll in prefix.glob('*.dll'):snapshot(dll,inputs/'bin'/dll.name)
env=os.environ.copy();env['PATH']=str(inputs/'bin')+os.pathsep+env['PATH']
text=(inputs/'original.cpp').read_text()
variants={'control':text,
'without-hi-tail':text.replace('-action_hi_tail[i],','0.0,'),
'without-lo-tail':text.replace('-action_lo_tail[i]','0.0'),
'without-error-lo':text.replace('{error_lo[i], error_lo[i]}','{0.0, 0.0}')}
assert all(value!=text for name,value in variants.items() if name!='control')
assert text.count('-action_hi_tail[i],')==text.count('-action_lo_tail[i]')==text.count('{error_lo[i], error_lo[i]}')==1
results=[]
for name,data in variants.items():
    target=work/name;target.mkdir()
    cpp=target/'helper.cpp';cpp.write_text(data,newline='\n')
    for header in private.glob('*.hpp'):shutil.copy2(header,target/header.name)
    obj=target/'helper.obj';pdb=target/'compile.pdb';exe=target/'runner.exe'
    command=original_compile.replace(entry['file'],'"'+str(cpp)+'"')
    command=command.replace(str(owner/'include'),str(headers))
    command=re.sub(r'/Fo[^ ]+',lambda _: '/Fo"'+str(obj)+'"',command,count=1)
    command=re.sub(r'/Fd[^ ]+',lambda _: '/Fd"'+str(pdb)+'"',command,count=1)
    assert str(source) not in command and str(owner/'include') not in command
    compiled=subprocess.run(command,cwd=target,env=env,capture_output=True,text=True,timeout=120)
    (target/'compile.log').write_text(compiled.stdout+compiled.stderr,newline='\n')
    if compiled.returncode:raise RuntimeError(f'{name} compile failed: {compiled.stdout} {compiled.stderr}')
    linked=[link_template[0],str(obj),*link_template[1:]]
    for i,arg in enumerate(linked):
        for option,value in (('/out:',exe),('/implib:',target/'runner.lib'),('/pdb:',target/'link.pdb')):
            if arg.lower().startswith(option):linked[i]=option+str(value)
    output=subprocess.run(linked,cwd=target,env=env,capture_output=True,text=True,timeout=30)
    (target/'link.log').write_text(output.stdout+output.stderr,newline='\n')
    if output.returncode:raise RuntimeError(f'{name} link failed: {output.stdout} {output.stderr}')
    args=[str(exe),'--reporter','compact','--rng-seed','424242']
    test=subprocess.run(args,cwd=target,env=env,capture_output=True,text=True,timeout=30)
    (target/'test.log').write_text(test.stdout+test.stderr,newline='\n')
    item={'name':name,'compile_command':command,'link_command':linked,'test_command':args,'compile_exit':compiled.returncode,'link_exit':output.returncode,'test_exit':test.returncode,'source_sha256':hashlib.sha256(cpp.read_bytes()).hexdigest(),'test_log_sha256':hashlib.sha256((target/'test.log').read_bytes()).hexdigest()}
    results.append(item)
    (work/'results.json').write_text(json.dumps({'inputs':files,'original_compile':original_compile,'results':results},indent=2),newline='\n')
    print(name,'compile',compiled.returncode,'link',output.returncode,'test',test.returncode,flush=True)
    print('\n'.join(test.stdout.splitlines()[-4:]),flush=True)
    assert test.returncode==(0 if name=='control' else 42),(name,test.returncode)
# Detect source/header/object changes after the snapshot without changing any owner files.
changed=[name for name,entry in files.items() if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=entry['sha256']]
(work/'owner-after.json').write_text(json.dumps({'changed_after_snapshot':changed},indent=2),newline='\n')
print('snapshot inputs',len(files),'owner changes after snapshot',changed,flush=True)
