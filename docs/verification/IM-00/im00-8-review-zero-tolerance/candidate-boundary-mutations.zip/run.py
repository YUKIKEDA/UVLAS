import hashlib,json,pathlib,re,shutil,subprocess,time,os
root=pathlib.Path.cwd();base=root/'.dev/im00-8-zero-tolerance/mutations';snapshot=base/'snapshot';snapshot.mkdir()
source=root/'src/numerics/gmres_solve.cpp';original=source.read_text()
for h in (root/'src/numerics').glob('*.hpp'):shutil.copy2(h,snapshot/h.name)
shutil.copytree(root/'include',snapshot/'include')
(snapshot/'gmres_solve.original.cpp').write_bytes(source.read_bytes())
entries=json.loads((root/'out/build/windows-msvc/compile_commands.json').read_text())
entry=next(e for e in entries if e['file'].replace('\\','/').endswith('src/numerics/gmres_solve.cpp') and 'Release' in e['command'] and 'uvlas_numerics_audit' not in e['command'])
build=root/'out/build/windows-msvc'
for filename in ['uvlas_numerics.lib','uvlas_core.lib']:shutil.copy2(build/'Release'/filename,snapshot/filename)
for kind in ['contract','solve']:shutil.copy2(build/f'tests/CMakeFiles/uvlas_test_numerics_gmres_{kind}.dir/Release/numerics/gmres_{kind}_test.cpp.obj',snapshot/f'{kind}.obj')
prefix=pathlib.Path('<repo>/out/vcpkg_installed/x64-windows')
raw_old='''    if (!combined)
        return std::unexpected(combined.error());'''
raw_new='''    if (!combined) {
        if (combined.error().code == FailureCode::PrecisionUnresolved) {
            std::fill(d.residual.values().begin(), d.residual.values().end(), 0.0);
            std::fill(d.residual_error.values().begin(), d.residual_error.values().end(), 0.0);
            return CandidateEvaluation{UnrepresentableMetrics{}};
        }
        return std::unexpected(combined.error());
    }'''
callback_old='''        if (!r)
            return std::unexpected(r.error());'''
callback_new='''        if (!r) {
            if (r.error().code == FailureCode::PrecisionUnresolved)
                return CandidateEvaluation{UnrepresentableMetrics{}};
            return std::unexpected(r.error());
        }'''
mutations={ 'control':original }
needle='''        if (metrics.error().code == FailureCode::PrecisionUnresolved)
            return CandidateEvaluation{UnrepresentableMetrics{}};'''
assert original.count(needle)==1
mutations['old_metric_failure']=original.replace(needle,'''        if (metrics.error().code == FailureCode::PrecisionUnresolved)
            return std::unexpected(metrics.error());''',1)
assert original.count(raw_old)==1;mutations['ignore_raw_failure']=original.replace(raw_old,raw_new,1)
a=original.index('Result<CandidateEvaluation> evaluate(');b=original.index('// Left preconditioning acts',a);part=original[a:b]
assert part.count(callback_old)==3
part=part.replace(callback_old,callback_new)
mutations['ignore_callback_failure']=original[:a]+part+original[b:]
results=[]
for name,text in mutations.items():
 folder=base/name;folder.mkdir();mutant=snapshot/'gmres_solve.cpp';mutant.write_text(text,encoding='utf-8',newline='\n')
 (folder/'gmres_solve.cpp').write_bytes(mutant.read_bytes())
 command=entry['command'];assert command.count(entry['file'])==1;command=command.replace(entry['file'],str(mutant))
 command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(folder/'solver.obj'),command);command=re.sub(r'/Fd\S+',lambda _: '/Fd'+str(folder/'solver.pdb'),command);command=command.replace(str(root/'include'),str(snapshot/'include'))
 commands=[command];start=time.monotonic();status={'name':name,'source_sha256':hashlib.sha256(mutant.read_bytes()).hexdigest()}
 try:
  compiled=subprocess.run(command,shell=True,cwd=entry['directory'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45);(folder/'compile.log').write_bytes(compiled.stdout);status['compile_exit']=compiled.returncode
  if compiled.returncode:results.append(status);continue
  exits=[]
  for kind in ['contract','solve']:
   exe=folder/f'{kind}.exe';args=['link.exe','/nologo','/INCREMENTAL:NO','/subsystem:console','/machine:x64','/out:'+str(exe),str(folder/'solver.obj'),str(snapshot/f'{kind}.obj'),str(snapshot/'uvlas_numerics.lib'),str(snapshot/'uvlas_core.lib'),str(prefix/'lib/manual-link/Catch2Main.lib'),str(prefix/'lib/Catch2.lib'),'psapi.lib','kernel32.lib','user32.lib','gdi32.lib','winspool.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','advapi32.lib'];commands.append(args)
   linked=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30);(folder/f'{kind}-link.log').write_bytes(linked.stdout)
   if linked.returncode:status[f'{kind}_link_exit']=linked.returncode;break
   env=dict(os.environ);env['PATH']=str(prefix/'bin')+';'+env['PATH'];ran=subprocess.run([str(exe),'--reporter','console'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15);(folder/f'{kind}-run.log').write_bytes(ran.stdout);exits.append(ran.returncode)
  status['run_exits']=exits;status['detected']=any(e!=0 for e in exits) if name!='control' else all(e==0 for e in exits) and len(exits)==2
 except subprocess.TimeoutExpired as e:status['timeout']=True;(folder/'timeout.log').write_bytes(e.stdout or b'')
 status['seconds']=time.monotonic()-start;(folder/'commands.json').write_text(json.dumps(commands,indent=2),encoding='utf-8');results.append(status);(base/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print(status,flush=True)
 if name=='control' and not status.get('detected'):raise SystemExit('control failed')
manifest={str(p.relative_to(snapshot)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.rglob('*') if p.is_file() and p.name!='gmres_solve.cpp'}
(base/'snapshot.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
