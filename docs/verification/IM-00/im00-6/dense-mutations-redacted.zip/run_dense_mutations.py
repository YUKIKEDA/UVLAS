from pathlib import Path
import hashlib,json,shutil,subprocess,time
repo=Path(__file__).resolve().parents[1]
p=repo/'.dev/im00-6-mutations';p.mkdir(exist_ok=True)
for folder in ['include']:
 shutil.copytree(repo/folder,p/folder,dirs_exist_ok=True)
files=['src/core/checked_dimensions.cpp','src/core/error_certificate.cpp','src/core/state.cpp','src/numerics/storage.cpp','src/numerics/precision.cpp','src/numerics/backend_memory.cpp','src/numerics/backend_memory_detail.hpp','src/numerics/linear_solve_detail.hpp','src/numerics/linear_metrics.cpp','src/numerics/linear_result.cpp','src/numerics/linear_validation.cpp','src/numerics/compensated.hpp','src/numerics/eigen_views.hpp','src/numerics/dense_solve.cpp','tests/numerics/dense_solve_test.cpp','tests/numerics/dense_allocations_test.cpp','tests/support/allocation_audit.cpp','tests/support/allocation_audit.hpp']
for name in files:
 destination=p/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,destination)
manifest={str(f.relative_to(p)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for folder in ['include','src','tests'] for f in (p/folder).rglob('*') if f.is_file()}
(p/'snapshot.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8',newline='\n')
cpp=[name for name in files if name.endswith('.cpp')]
(p/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(dense_mutations LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
find_package(Catch2 3 CONFIG REQUIRED)
find_package(Eigen3 CONFIG REQUIRED)
find_package(boost_headers CONFIG REQUIRED)
add_executable(probe '''+' '.join(cpp)+''')
target_include_directories(probe PRIVATE include src/numerics)
target_link_libraries(probe PRIVATE Catch2::Catch2WithMain Eigen3::Eigen Boost::headers)
target_compile_definitions(probe PRIVATE EIGEN_RUNTIME_NO_MALLOC EIGEN_DONT_PARALLELIZE EIGEN_MPL2_ONLY)
target_compile_options(probe PRIVATE /W4 /WX /UNDEBUG /permissive- /fp:strict /EHsc)
''',encoding='utf-8',newline='\n')
def run(name,args,timeout=120):
 try:
  r=subprocess.run(args,cwd=repo,capture_output=True,text=True,timeout=timeout)
  (p/(name+'.log')).write_text(r.stdout+r.stderr,encoding='utf-8',newline='\n')
  return {'returncode':r.returncode,'timeout':False}
 except subprocess.TimeoutExpired as e:
  (p/(name+'.log')).write_text(str(e.stdout)+str(e.stderr),encoding='utf-8',newline='\n')
  return {'returncode':None,'timeout':True}
wrapper=['pwsh','-File',str(repo/'tools/dev/msvc.ps1')]
configure_args=['cmake','-S',str(p),'-B',str(p/'build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=cl','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=<repo>/out/vcpkg_installed/x64-windows','-DCMAKE_MAKE_PROGRAM=<home>/AppData/Local/Programs/Python/Python310/Scripts/ninja.exe']
configure_text="& '"+str(repo/'tools/dev/msvc.ps1').replace("'","''")+"' "+' '.join("'"+arg.replace("'","''")+"'" for arg in configure_args)
configuration=run('configure',['pwsh','-NoProfile','-Command',configure_text])
assert configuration['returncode']==0,configuration
build_command=wrapper+['cmake','--build',str(p/'build'),'-j','2']
build=run('control-build',build_command);assert build['returncode']==0,build
control=run('control',[str(p/'build/probe.exe')],20);assert control['returncode']==0,control
source=p/'src/numerics/dense_solve.cpp';original=source.read_text(encoding='utf-8')
mutants=[
 ('conjugate_original_update','v = entry(data.v, col, k)','v = std::conj(entry(data.v, col, k))'),
 ('disable_progress_promotion','if (!two && refinements > 0)','if (false && !two && refinements > 0)'),
 ('discard_initial_low_rhs','data.rhs_lo.values()[at] = rhs_low ? entry(*rhs_low, i, c) : Scalar{};','data.rhs_lo.values()[at] = Scalar{};'),
 ('erase_correction_diagnostic','metric->normalized_original_residual_upper;','0;'),
 ('threshold_nonzero_pivot','std::abs(factor.matrixLU()(i, i)) == 0','std::abs(factor.matrixLU()(i, i)) < 1e-200'),
 ('allocate_inside_kernel','    while (true) {','    while (true) { void* unexpected_allocation=::operator new(8); ::operator delete(unexpected_allocation);')]
records=[]
try:
 for name,old,new in mutants:
  assert old in original,(name,'anchor missing')
  changed=original.replace(old,new)
  if name=='discard_initial_low_rhs':changed=changed.replace('const auto* rhs_low = low(rhs.values());','')
  source.write_text(changed,encoding='utf-8',newline='\n')
  built=run(name+'-build',build_command)
  executed=run(name+'-run',[str(p/'build/probe.exe')],20) if built['returncode']==0 else None
  record={'name':name,'build':built,'execution':executed,'detected':bool(executed and executed['returncode'] not in [0,None])}
  records.append(record);print(record,flush=True)
  (p/'results.json').write_text(json.dumps({'configuration':configuration,'control_build':build,'control':control,'mutants':records},indent=2),encoding='utf-8',newline='\n')
  source.write_text(original,encoding='utf-8',newline='\n')
finally:
 source.write_text(original,encoding='utf-8',newline='\n')
