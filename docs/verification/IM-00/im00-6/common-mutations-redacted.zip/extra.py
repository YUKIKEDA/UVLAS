from pathlib import Path
import subprocess,json
p=Path(__file__).parent;repo=Path(r'<repo>');f=p/'src/numerics/linear_result.cpp';original=f.read_bytes();s=f.read_text();data=json.loads((p/'results.json').read_text())
changes=[('disable_consumer_context_only','proof->context() != expected','false'),('disable_consumer_budget_only','std::bit_cast<std::uint64_t>(proof->budget()) !=\n                                                std::bit_cast<std::uint64_t>(check.budget)','false')]
try:
 for name,old,new in changes:
  assert old in s;f.write_text(s.replace(old,new));b=subprocess.run(['pwsh','-File',str(repo/'tools/dev/msvc.ps1'),'cmake','--build',str(p/'build'),'-j','2'],capture_output=True,text=True,timeout=90);(p/(name+'-build.log')).write_text(b.stdout+b.stderr)
  r=subprocess.run([str(p/'build/probe.exe')],capture_output=True,text=True,timeout=20) if b.returncode==0 else None
  if r:(p/(name+'-run.log')).write_text(r.stdout+r.stderr)
  data['mutants'].append({'name':name,'build':{'returncode':b.returncode},'execution':{'returncode':r.returncode} if r else None,'detected_by_executable':r is not None and r.returncode!=0});print(data['mutants'][-1],flush=True);f.write_bytes(original)
finally:
 f.write_bytes(original);(p/'results.json').write_text(json.dumps(data,indent=2))
 b=subprocess.run(['pwsh','-File',str(repo/'tools/dev/msvc.ps1'),'cmake','--build',str(p/'build'),'-j','2'],capture_output=True,text=True,timeout=90);(p/'restore-build.log').write_text(b.stdout+b.stderr)
