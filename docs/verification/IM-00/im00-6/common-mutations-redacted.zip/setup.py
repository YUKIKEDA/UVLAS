import pathlib, shutil, hashlib, json
s=pathlib.Path(r'<repo>')
d=pathlib.Path(r'<repo>/.dev/common-mutations-review')
shutil.copytree(s/'include',d/'include',dirs_exist_ok=True)
files=['src/core/checked_dimensions.cpp','src/core/error_certificate.cpp','src/numerics/storage.cpp','src/numerics/precision.cpp','src/numerics/backend_memory.cpp','src/numerics/backend_memory_detail.hpp','src/numerics/linear_solve_detail.hpp','src/numerics/linear_metrics.cpp','src/numerics/linear_result.cpp','src/numerics/linear_validation.cpp','tests/numerics/linear_metrics_test.cpp','tests/numerics/linear_result_test.cpp']
for p in files:
 (d/p).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(s/p,d/p)
manifest={str(p.relative_to(d)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in d.rglob('*') if p.is_file()}
(d/'snapshot.json').write_text(json.dumps(manifest,indent=2))
(d/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(common_mutations LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
find_package(Catch2 3 CONFIG REQUIRED)
find_package(Boost CONFIG REQUIRED)
add_executable(probe src/core/checked_dimensions.cpp src/core/error_certificate.cpp src/numerics/storage.cpp src/numerics/precision.cpp src/numerics/backend_memory.cpp src/numerics/linear_metrics.cpp src/numerics/linear_result.cpp src/numerics/linear_validation.cpp tests/numerics/linear_metrics_test.cpp tests/numerics/linear_result_test.cpp)
target_include_directories(probe PRIVATE include src/numerics)
target_link_libraries(probe PRIVATE Catch2::Catch2WithMain Boost::headers)
target_compile_options(probe PRIVATE /W4 /WX /permissive- /fp:strict /EHsc)
''')
