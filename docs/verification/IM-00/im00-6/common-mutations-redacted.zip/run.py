from pathlib import Path
import subprocess,json,hashlib,time
p=Path(__file__).parent
repo=Path(r'<repo>')
metrics=p/'src/numerics/linear_metrics.cpp'; result=p/'src/numerics/linear_result.cpp'
original={metrics:metrics.read_text(),result:result.read_text()}
mutants=[
('drop_low',metrics,'two_sum(high, low)','two_sum(high, 0.0)'),
('ignore_relative',metrics,'multiply_bound(accuracy.relative_tolerance, rhs->lower, false)','multiply_bound(0.0, rhs->lower, false)'),
('zero_positive_quotient_underflow',metrics,'return up ? std::numeric_limits<double>::denorm_min() : 0;','return 0;'),
('gate_returned_as_retained',result,'aggregate(metadata.returned_columns.values(),','aggregate(metadata.retained_columns.values(),'),
('disable_consumer_identity_budget',result,'if (proof->context() != expected || std::bit_cast<std::uint64_t>(proof->budget()) !=\n                                                std::bit_cast<std::uint64_t>(check.budget)) {','if (false) {'),
('only_first_consumer',result,'i < precision.required_checks.size();','i < std::min<std::size_t>(1, precision.required_checks.size());')]
records=[]
def run(name,args,timeout):
 try:
  r=subprocess.run(args,cwd=repo,capture_output=True,text=True,timeout=timeout)
  (p/(name+'.log')).write_text(r.stdout+r.stderr)
  return {'returncode':r.returncode,'timeout':False}
 except subprocess.TimeoutExpired as e:
  (p/(name+'.log')).write_text(str(e.stdout)+str(e.stderr)); return {'returncode':None,'timeout':True}
manifest={str(f.relative_to(p)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for folder in ['include','src','tests'] for f in (p/folder).rglob('*') if f.is_file()}
(p/'snapshot.json').write_text(json.dumps(manifest,indent=2))
control=run('control',[str(p/'build/probe.exe')],20)
assert control['returncode']==0,control
try:
 for name,file,old,new in mutants:
  assert old in original[file],(name,'missing anchor')
  file.write_text(original[file].replace(old,new))
  build=run(name+'-build',['pwsh','-File',str(repo/'tools/dev/msvc.ps1'),'cmake','--build',str(p/'build'),'-j','2'],90)
  execution=run(name+'-run',[str(p/'build/probe.exe')],20) if build['returncode']==0 else None
  records.append({'name':name,'source':str(file.relative_to(p)),'build':build,'execution':execution,'detected_by_executable':execution is not None and execution['returncode'] not in [0,None]})
  file.write_text(original[file])
  (p/'results.json').write_text(json.dumps({'control':control,'mutants':records},indent=2))
  print(name,records[-1],flush=True)
finally:
 for f,s in original.items():f.write_text(s)
 restore=run('restore-build',['pwsh','-File',str(repo/'tools/dev/msvc.ps1'),'cmake','--build',str(p/'build'),'-j','2'],90)
 (p/'restore.json').write_text(json.dumps(restore))
