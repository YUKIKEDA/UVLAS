import pathlib,json,hashlib,shutil
p=pathlib.Path(r'<repo>/.dev/common-mutations-review'); s=pathlib.Path(r'<repo>')
m=json.loads((p/'snapshot.json').read_text())
for name in ['src/numerics/linear_metrics.cpp','src/numerics/linear_result.cpp']:
 assert hashlib.sha256((s/name).read_bytes()).hexdigest()==m[name],name
 shutil.copy2(s/name,p/name)
summary={'snapshot_manifest_sha256':hashlib.sha256((p/'snapshot.json').read_bytes()).hexdigest(),'sources':{name:m[name] for name in ['src/numerics/linear_metrics.cpp','src/numerics/linear_result.cpp','tests/numerics/linear_metrics_test.cpp','tests/numerics/linear_result_test.cpp']},'restored_bytes_match':all(hashlib.sha256((p/name).read_bytes()).hexdigest()==digest for name,digest in m.items())}
(p/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
