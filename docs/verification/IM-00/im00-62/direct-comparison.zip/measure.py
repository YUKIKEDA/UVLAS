import hashlib,json,os,pathlib,statistics,subprocess,time
folder=pathlib.Path('.dev/im00-62/performance').resolve();prefix=pathlib.Path('<repo>/out/vcpkg_installed/x64-windows');env=dict(os.environ);env['PATH']=str(prefix/'bin')+';'+env['PATH'];rows=[];order=[]
for round_index in range(3):
 for label in ['baseline','fixed']:
  started=time.time();r=subprocess.run([str(folder/(label+'.exe'))],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=60);finished=time.time();(folder/f'{label}-{round_index}.json').write_bytes(r.stdout);(folder/f'{label}-{round_index}.stderr').write_bytes(r.stderr)
  assert r.returncode==0,(label,r.returncode,r.stderr)
  result=json.loads(r.stdout);order.append({'label':label,'round':round_index,'started_utc_epoch':started,'finished_utc_epoch':finished,'exit':r.returncode})
  for value in result:rows.append({'label':label,'round':round_index,**value})
  print(label,round_index,finished-started,flush=True)
summary=[]
for case in ['dense64','updated64','sparse1024']:
 before=[r for r in rows if r['case']==case and r['label']=='baseline'];after=[r for r in rows if r['case']==case and r['label']=='fixed']
 expected=before[0]['numeric_words'];assert all(r['numeric_words']==expected for r in before+after),(case,'returned bits differ')
 result={'case':case,'numeric_words_equal':True,'compared_words':len(expected),'iterations_per_round':before[0]['iterations'],'baseline_prepare_payload':before[0]['prepare_payload_bytes'],'fixed_prepare_payload':after[0]['prepare_payload_bytes'],'baseline_solve_payload':before[0]['solve_payload_bytes'],'fixed_solve_payload':after[0]['solve_payload_bytes']}
 for label,values in [('baseline',before),('fixed',after)]:
  for metric in ['prepare_mean_seconds','solve_mean_seconds']:
   samples=[x[metric] for x in values];result[label+'_'+metric]={'samples':samples,'median':statistics.median(samples),'minimum':min(samples),'maximum':max(samples)}
 summary.append(result)
(folder/'measurement-order.json').write_text(json.dumps(order,indent=2),encoding='utf-8');(folder/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2))
