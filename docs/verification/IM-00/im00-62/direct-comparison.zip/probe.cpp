#include <array>
#include <bit>
#include <chrono>
#include <complex>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <locale>
#include <stdexcept>
#include <string_view>
#include <uvlas/numerics/dense_solve.hpp>
#include <uvlas/numerics/sparse_solve.hpp>
#include <vector>
namespace {
using namespace uvlas;
using namespace numerics;
using namespace numerics::linear;
constexpr auto operation = core::Operation::SolveLinear;
constexpr unsigned iterations = 128;
Context context() {
    return {{core::ModelFingerprint{}, core::ModelGeneration{1}, core::GeometryGeneration{1},
             core::ChartGeneration{1}, core::SparsityGeneration{1}, core::NumericalGeneration{1},
             core::ScaleGeneration{1}, core::PrecisionGeneration{1}, core::Precision::Binary64,
             core::WakePolicyGeneration{1}, core::TimeIntervalGeneration{1},
             core::BackendGeneration{1}},
            core::TrialId{1},
            core::ScopeId{1},
            core::ScopeId{2},
            0};
}
template <class T>
T take(core::Result<T> r) {
    if (!r)
        throw std::runtime_error("probe operation failed");
    return std::move(*r);
}
template <StorageScalar T>
class NoChecks final : public ConsumerEvaluator<T> {
public:
    SupportedPrecision supported_precision() const noexcept override {
        return SupportedPrecision::Binary64AndTwoWord;
    }
    core::Result<core::ErrorCertificate> assess(const PrecisionBuffer<T>&,
                                                const PrecisionBuffer<T>&, const Context&,
                                                const ConsumerCheck& c,
                                                core::CertificateContext e) const override {
        return core::ErrorCertificate::unevaluated(e, c.budget);
    }
};
void word(std::vector<std::uint64_t>& out, double x) {
    out.push_back(std::bit_cast<std::uint64_t>(x));
}
void word(std::vector<std::uint64_t>& out, std::complex<double> x) {
    word(out, x.real());
    word(out, x.imag());
}
template <StorageScalar T>
std::vector<std::uint64_t> bits(const Solution<T>& result) {
    std::vector<std::uint64_t> out;
    const auto& values = result.values();
    out.push_back(static_cast<std::uint64_t>(values.precision()));
    if (const auto* b = std::get_if<Binary64<T>>(&values.storage()))
        for (auto x : b->values.values())
            word(out, x);
    else {
        const auto& w = *std::get_if<TwoWord<T>>(&values.storage());
        for (auto x : w.hi.values())
            word(out, x);
        for (auto x : w.lo.values())
            word(out, x);
    }
    out.push_back(result.certificate().refinements());
    for (const auto& m : result.certificate().retained_columns()) {
        word(out, m.normalized_original_residual_upper);
        word(out, m.componentwise_backward_error_upper);
        word(out, m.scaled_correction_upper);
    }
    for (const auto& m : result.certificate().columns()) {
        word(out, m.normalized_original_residual_upper);
        word(out, m.componentwise_backward_error_upper);
        word(out, m.scaled_correction_upper);
    }
    return out;
}
template <StorageScalar T, class Operator, class Prepare>
void run(std::string_view name, const Operator& op, const Scales& scales, const Limits& limits,
         const PrecisionBuffer<T>& b, Prepare prepare) {
    std::uint64_t payload = 0;
    const auto begin = std::chrono::steady_clock::now();
    for (unsigned k = 0; k < iterations; ++k) {
        core::ResourcePlan plan{1 << 27};
        auto prepared = take(prepare(plan));
        payload = plan.allocated_bytes();
        (void)prepared;
    }
    const auto ready = std::chrono::steady_clock::now();
    core::ResourcePlan workspace{1 << 27};
    auto prepared = take(prepare(workspace));
    const NoChecks<T> consumer;
    const Precision<T> precision{RetainedPrecision{core::NumericalGeneration{3}}, {}, consumer};
    const Accuracy accuracy{Norm::Infinity,        1e-12, 0, 1e-12, core::ObservationId{1},
                            core::ObservationId{2}};
    const Rhs<T> rhs{b, context(), core::RhsGeneration{1}};
    const auto solve_start = std::chrono::steady_clock::now();
    for (unsigned k = 0; k < iterations; ++k) {
        core::ResourcePlan output{1 << 27};
        auto result =
            take(solve_linear(op, rhs, scales, precision, accuracy, limits, prepared, output));
        (void)result;
    }
    const auto done = std::chrono::steady_clock::now();
    core::ResourcePlan output{1 << 27};
    const auto result =
        take(solve_linear(op, rhs, scales, precision, accuracy, limits, prepared, output));
    const auto words = bits(result);
    std::cout << "{\"case\":\"" << name << "\",\"iterations\":" << iterations
              << ",\"prepare_mean_seconds\":"
              << std::chrono::duration<double>(ready - begin).count() / iterations
              << ",\"solve_mean_seconds\":"
              << std::chrono::duration<double>(done - solve_start).count() / iterations
              << ",\"prepare_payload_bytes\":" << payload
              << ",\"solve_payload_bytes\":" << output.allocated_bytes() << ",\"numeric_words\":[";
    for (std::size_t i = 0; i < words.size(); ++i) {
        if (i)
            std::cout << ',';
        std::cout << '"' << std::hex << words[i] << std::dec << '"';
    }
    std::cout << "]}";
}
void dense() {
    constexpr core::Index n = 64;
    core::ResourcePlan inputs{1 << 27};
    std::vector<double> coefficients(n * n, 0), scale(n, 1);
    std::vector<UnitDimensions> units(n);
    for (core::Index i = 0; i < n; ++i)
        coefficients[static_cast<std::size_t>(i * n + i)] = 4;
    auto a = take(DenseReal::copy({n, n, n}, coefficients, inputs, operation));
    auto b = take(DenseReal::copy({n, 1, n}, scale, inputs, operation));
    auto rhs = take(PrecisionBuffer<double>::binary64(std::move(b), core::NumericalGeneration{2}));
    const Scales scales{scale, scale, units, units, context()};
    const Limits limits{n, 1, 0, 5, EstimateAdmission{1 << 27}};
    const DenseOperator op{a, context()};
    run("dense64", op, scales, limits, rhs,
        [&](core::ResourcePlan& plan) { return DensePrepared::prepare(op, scales, limits, plan); });
}
void updated() {
    using C = std::complex<double>;
    constexpr core::Index n = 64;
    core::ResourcePlan inputs{1 << 27};
    std::vector<double> coefficients(n * n, 0), scale(n, 1);
    std::vector<UnitDimensions> units(n);
    for (core::Index i = 0; i < n; ++i)
        coefficients[static_cast<std::size_t>(i * n + i)] = 4;
    std::vector<C> us(n, C{0, 1. / 32}), vs(n, C{1. / 16, 1. / 16}), bs(n, C{1, 1. / 8});
    auto a = take(DenseReal::copy({n, n, n}, coefficients, inputs, operation));
    auto u = take(DenseComplex::copy({n, 1, n}, us, inputs, operation));
    auto v = take(DenseComplex::copy({n, 1, n}, vs, inputs, operation));
    auto b = take(DenseComplex::copy({n, 1, n}, bs, inputs, operation));
    auto rhs = take(PrecisionBuffer<C>::binary64(std::move(b), core::NumericalGeneration{2}));
    const Scales scales{scale, scale, units, units, context()};
    const Limits limits{n, 1, 1, 5, EstimateAdmission{1 << 27}};
    const ColumnUpdatedOperator op{a, u, v, context()};
    run("updated64", op, scales, limits, rhs, [&](core::ResourcePlan& plan) {
        return UpdatedPrepared::prepare(op, scales, limits, plan);
    });
}
void sparse() {
    constexpr core::Index n = 1024;
    core::ResourcePlan inputs{1 << 27};
    std::vector<double> scale(n, 1);
    std::vector<UnitDimensions> units(n);
    std::vector<Triplet> entries;
    for (core::Index i = 0; i < n; ++i) {
        entries.push_back({i, i, 4});
        if (i)
            entries.push_back({i - 1, i, -1});
        if (i + 1 < n)
            entries.push_back({i + 1, i, -1});
    }
    auto a = take(SparseReal::from_triplets(n, n, entries, inputs, operation));
    auto b = take(DenseReal::copy({n, 1, n}, scale, inputs, operation));
    auto rhs = take(PrecisionBuffer<double>::binary64(std::move(b), core::NumericalGeneration{2}));
    const Scales scales{scale, scale, units, units, context()};
    const Limits limits{n, 1, 0, 5, EstimateAdmission{1 << 27}};
    const SparseOperator op{a, context()};
    run("sparse1024", op, scales, limits, rhs, [&](core::ResourcePlan& plan) {
        return SparsePrepared::prepare(op, scales, SparseMethod::GeneralLu, limits, plan);
    });
}
} // namespace
int main() {
    try {
        std::cout.imbue(std::locale::classic());
        std::cout << std::setprecision(17) << "[";
        dense();
        std::cout << ",";
        updated();
        std::cout << ",";
        sparse();
        std::cout << "]\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
