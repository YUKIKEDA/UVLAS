import hashlib,json,pathlib,re,shutil,subprocess
root=pathlib.Path.cwd();folder=root/'.dev/im00-62/performance';source=folder/'source';source.mkdir(exist_ok=True)
for h in (root/'src/numerics').glob('*.hpp'):shutil.copy2(h,source/h.name)
entries=json.loads((root/'out/build/windows-msvc/compile_commands.json').read_text())
commands=[];inputs={}
for name in ['dense_solve.cpp','sparse_solve.cpp']:
 data=subprocess.check_output(['git','show','1bed1bce975d815ac5defd5068a588df281697ad:src/numerics/'+name]);(source/name).write_bytes(data);inputs['baseline/'+name]=hashlib.sha256(data).hexdigest()
 entry=next(e for e in entries if e['file'].replace('\\','/').endswith('src/numerics/'+name) and 'Release' in e['command'] and 'uvlas_numerics_audit' not in e['command'])
 command=entry['command'];assert command.count(entry['file'])==1;command=command.replace(entry['file'],str(source/name));command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(folder/(name+'.obj')),command);command=re.sub(r'/Fd\S+',lambda _: '/Fd'+str(folder/(name+'.pdb')),command)
 commands.append(command);r=subprocess.run(command,shell=True,cwd=entry['directory'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120);(folder/(name+'.compile.log')).write_bytes(r.stdout);print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
entry=next(e for e in entries if e['file'].replace('\\','/').endswith('src/numerics/dense_solve.cpp') and 'Release' in e['command'] and 'uvlas_numerics_audit' not in e['command'])
command=entry['command'].replace(entry['file'],str(folder/'probe.cpp'));command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(folder/'probe.obj'),command);command=re.sub(r'/Fd\S+',lambda _: '/Fd'+str(folder/'probe.pdb'),command);commands.append(command)
r=subprocess.run(command,shell=True,cwd=entry['directory'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120);(folder/'probe.compile.log').write_bytes(r.stdout);print('probe',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
(folder/'compile-commands.json').write_text(json.dumps(commands,indent=2),encoding='utf-8')
inputs['probe.cpp']=hashlib.sha256((folder/'probe.cpp').read_bytes()).hexdigest();(folder/'compile-inputs.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
