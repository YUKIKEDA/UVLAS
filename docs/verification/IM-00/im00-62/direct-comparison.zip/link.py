import hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path.cwd();folder=root/'.dev/im00-62/performance';snapshot=folder/'libraries';snapshot.mkdir(exist_ok=True)
inputs={};commands=[]
for name in ['uvlas_numerics.lib','uvlas_core.lib']:
 p=root/'out/build/windows-msvc/Release'/name;shutil.copy2(p,snapshot/name);inputs[name]=hashlib.sha256(p.read_bytes()).hexdigest()
prefix=pathlib.Path('<repo>/out/vcpkg_installed/x64-windows')
for label in ['baseline','fixed']:
 args=['link.exe','/nologo','/INCREMENTAL:NO','/subsystem:console','/machine:x64','/out:'+str(folder/(label+'.exe')),str(folder/'probe.obj')]
 if label=='baseline':args += [str(folder/'dense_solve.cpp.obj'),str(folder/'sparse_solve.cpp.obj')]
 args += [str(snapshot/'uvlas_numerics.lib'),str(snapshot/'uvlas_core.lib'),str(prefix/'lib/boost_container-vc145-mt-x64-1_92.lib'),str(prefix/'lib/boost_random-vc145-mt-x64-1_92.lib'),'psapi.lib','kernel32.lib','user32.lib','gdi32.lib','winspool.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','advapi32.lib']
 commands.append(args);r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30);(folder/(label+'.link.log')).write_bytes(r.stdout);print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 inputs[label+'.exe']=hashlib.sha256((folder/(label+'.exe')).read_bytes()).hexdigest()
(folder/'link-commands.json').write_text(json.dumps(commands,indent=2),encoding='utf-8');(folder/'link-inputs.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
