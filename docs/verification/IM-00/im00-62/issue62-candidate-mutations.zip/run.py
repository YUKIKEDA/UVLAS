from pathlib import Path
import hashlib, json, os, re, shlex, shutil, subprocess, time

OWNER = Path('<repo>')
WORK = Path(__file__).resolve().parent
BUILD = OWNER / 'out/build/windows-msvc'
INPUTS = WORK / 'inputs'
INPUTS.mkdir()
FILES = {}
RESULTS = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(source, target):
    before = source.stat()
    raw = source.read_bytes()
    after = source.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), source
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    assert sha(source) == sha(target), source
    FILES[str(source)] = {'snapshot': str(target), 'sha256': sha(target)}
    return target

for source in (OWNER / 'include').rglob('*.hpp'):
    snapshot(source, INPUTS / 'include' / source.relative_to(OWNER / 'include'))
for source in (OWNER / 'src/numerics').glob('*.hpp'):
    snapshot(source, INPUTS / 'private' / source.name)
for name in ('dense_solve.cpp', 'sparse_solve.cpp'):
    snapshot(OWNER / 'src/numerics' / name, INPUTS / 'source' / name)
snapshot(OWNER / 'tests/numerics/linear_candidate_test.cpp', INPUTS / 'source/linear_candidate_test.cpp')
snapshot(OWNER / 'tests/numerics/direct_progress_test.cpp', INPUTS / 'source/direct_progress_test.cpp')
assert 'linear_candidate_detail.hpp' not in (INPUTS / 'source/direct_progress_test.cpp').read_text()
DB = json.loads((BUILD / 'compile_commands.json').read_text())
LINK = {}
for group, target in [('public', 'direct_progress'), ('helper', 'linear_candidate')]:
    output = subprocess.run(['ninja', '-f', 'build-Release.ninja', '-t', 'commands',
                             f'uvlas_test_numerics_{target}'], cwd=BUILD,
                            capture_output=True, text=True, check=True, timeout=30).stdout
    line = next(line for line in output.splitlines() if 'link.exe' in line and 'vs_link_exe' in line)
    command = [part.strip('"') for part in shlex.split(line.split(' -- ', 1)[1].split(' && ', 1)[0], posix=False)]
    for index, value in enumerate(command):
        if value.lower().endswith(('.lib', '.obj')):
            source = Path(value)
            if not source.is_absolute():
                source = BUILD / source
            if source.is_file():
                dest = INPUTS / 'link' / source.name
                if not dest.exists():
                    snapshot(source, dest)
                command[index] = str(dest)
    LINK[group] = command
for source in Path('<repo>/out/vcpkg_installed/x64-windows/bin').glob('*.dll'):
    snapshot(source, INPUTS / 'bin' / source.name)
ENV = os.environ.copy()
ENV['PATH'] = str(INPUTS / 'bin') + os.pathsep + ENV['PATH']
HEADER = (INPUTS / 'private/linear_candidate_detail.hpp').read_text()
PATCHES = {
    'old-metric-failure': ('return CandidateMetrics{UnrepresentableMetrics{}};', 'return std::unexpected(metric.error());'),
    'without-raw-error-check': ('        if (!std::isfinite(absolute_error_upper[i]))\n            return fail(core::FailureCode::PrecisionUnresolved);\n', ''),
    'without-marker-promotion': ('    if (!now || !before)\n        return true;', '    if (!now || !before)\n        return false;'),
}
assert all(HEADER.count(old) == 1 for old, _ in PATCHES.values())

def run(name, group, mutation=None):
    folder = WORK / name
    folder.mkdir()
    for header in (INPUTS / 'private').glob('*.hpp'):
        shutil.copy2(header, folder / header.name)
    header = HEADER if mutation is None else HEADER.replace(*PATCHES[mutation])
    (folder / 'linear_candidate_detail.hpp').write_text(header, newline='\n')
    sources = ['dense_solve.cpp', 'sparse_solve.cpp'] if group == 'public' else ['linear_candidate_test.cpp']
    commands, objects = [], []
    start = time.time()
    for number, name_cpp in enumerate(sources):
        cpp = folder / name_cpp
        shutil.copy2(INPUTS / 'source' / name_cpp, cpp)
        entry = next(item for item in DB if item['file'].replace('\\', '/').endswith('/' + name_cpp)
                     and 'Release' in item['command'] and ('uvlas_numerics.dir' in item['command'] if group == 'public'
                     else 'uvlas_test_numerics_linear_candidate.dir' in item['command']))
        obj = folder / (name_cpp + '.obj')
        command = entry['command'].replace(entry['file'], '"' + str(cpp) + '"')
        command = command.replace(str(OWNER / 'include'), str(INPUTS / 'include'))
        command = command.replace(str(OWNER / 'src/numerics'), str(folder))
        command = re.sub(r'/Fo[^ ]+', lambda _: '/Fo"' + str(obj) + '"', command, count=1)
        command = re.sub(r'/Fd[^ ]+', lambda _: '/Fd"' + str(folder / 'compile.pdb') + '"', command, count=1)
        assert str(OWNER / 'include') not in command and str(OWNER / 'src/numerics') not in command
        process = subprocess.run(command, cwd=folder, env=ENV, capture_output=True, text=True, timeout=180)
        (folder / f'compile-{number}.log').write_text(process.stdout + process.stderr, newline='\n')
        assert process.returncode == 0, (name, name_cpp, process.stdout, process.stderr)
        commands.append(command)
        objects.append(str(obj))
    linked = LINK[group].copy()
    if group == 'helper':
        position = next(i for i, part in enumerate(linked) if part.endswith('linear_candidate_test.cpp.obj'))
        linked[position] = objects[0]
    else:
        linked[1:1] = objects
    for i, value in enumerate(linked):
        for option, target in [('/out:', folder / 'runner.exe'), ('/implib:', folder / 'runner.lib'), ('/pdb:', folder / 'link.pdb')]:
            if value.lower().startswith(option):
                linked[i] = option + str(target)
    linked.append('/MAP:' + str(folder / 'link.map'))
    process = subprocess.run(linked, cwd=folder, env=ENV, capture_output=True, text=True, timeout=30)
    (folder / 'link.log').write_text(process.stdout + process.stderr, newline='\n')
    assert process.returncode == 0, (name, process.stdout, process.stderr)
    linkmap = (folder / 'link.map').read_text()
    assert 'uvlas_numerics:dense_solve.cpp.obj' not in linkmap
    assert 'uvlas_numerics:sparse_solve.cpp.obj' not in linkmap
    if group == 'helper':
        assert 'dense_solve' not in linkmap and 'sparse_solve' not in linkmap
    args = [str(folder / 'runner.exe'), '--reporter', 'compact', '--rng-seed', '424242']
    process = subprocess.run(args, cwd=folder, env=ENV, capture_output=True, text=True, timeout=30)
    (folder / 'test.log').write_text(process.stdout + process.stderr, newline='\n')
    result = {'variant': name, 'group': group, 'mutation': mutation, 'compile_commands': commands,
              'link_command': linked, 'test_command': args, 'exit': process.returncode,
              'started_unix': start, 'finished_unix': time.time(), 'source_header_sha256': sha(folder / 'linear_candidate_detail.hpp'),
              'test_log_sha256': sha(folder / 'test.log'), 'link_map_sha256': sha(folder / 'link.map'),
              'no_original_dense_sparse_archive_members': True}
    RESULTS.append(result)
    (WORK / 'results.json').write_text(json.dumps({'source_commit': 'eb942f044c773706ffbd44ec58520dd5b908de4b',
        'timeouts_seconds': {'compile_per_tu': 180, 'link': 30, 'test': 30}, 'inputs': FILES, 'results': RESULTS}, indent=2), newline='\n')
    print(name, 'exit', process.returncode, flush=True)
    print('\n'.join(process.stdout.splitlines()[-5:]), flush=True)
    assert process.returncode == (0 if mutation is None else 42), (name, process.returncode)

run('public-control', 'public')
run('old-metric-failure', 'public', 'old-metric-failure')
run('helper-control', 'helper')
run('without-raw-error-check', 'helper', 'without-raw-error-check')
run('without-marker-promotion', 'helper', 'without-marker-promotion')
changed = [source for source, entry in FILES.items() if sha(Path(source)) != entry['sha256']]
(WORK / 'owner-after.json').write_text(json.dumps({'changed_after_snapshot': changed}, indent=2), newline='\n')
print('owner inputs changed', changed, flush=True)
