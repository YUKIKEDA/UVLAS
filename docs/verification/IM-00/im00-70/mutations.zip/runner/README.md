# Arnoldi隔離変異の準備

固定通知を受け取るまで実行しない。製品source/test/build/fixtureは変更しない。
runnerはC4で実行済みのcompile/link/map/hash検証を移し、private headerの変異に対応した。
各caseにprivate header全体をcopyし、nested quoted includeが変異を迂回しないようにする。
合意した4〜5件をJSONに明記し、明示されたproducer hashとconfigurationを渡す。

```text
pwsh -NoProfile -File tools/dev/msvc.ps1 uv run --offline --no-project python -X utf8 out/issue70-peer-mutations/run.py --build <fixed-build> --configuration Release --source-sha256 <frozen-sha256> --mutations out/issue70-peer-mutations/agreed.json
```

JSONの形：配列の各要素はnameとedits、各editはfile/before/afterを持つ。
fileはcopyしたprivate headerかeigen_arnoldi.cppのbasenameとする。
beforeは固定snapshotにちょうど1件存在しなければ停止する。
無変異controlを先に同じproducer/test object/libraryで通す。
compile/linkが成功し、実行結果が非0かつCatch assertion失敗を含むものだけをkillと数える。
全caseで元archiveのeigen_arnoldi.cpp.obj未抽出と専用producer symbolをmapから確認する。
source/header/test/object/fixture/lib/DB/Ninja/cache/runner/configの元hash不変を前後で確認する。
通常targetの数値・契約試験だけを使い、別audit archiveの試験は混在させない。
公開証拠はrawを複製して通常/符号化pathを伏せ、元hash・派生hashを記録する。
object/exe/lib/PDBを公開束へ入れない。最終製品版と変異snapshotの差は担当12が明記する。
