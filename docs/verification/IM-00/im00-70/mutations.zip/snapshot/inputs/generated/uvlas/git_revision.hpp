#pragma once

#define UVLAS_GIT_COMMIT "338f2d7bc93f00bc1381409997c2ea61d96da83c"
#define UVLAS_GIT_DIRTY 1
